//
//  GameScene.swift
//  Collect Ranom Block
//
//  Created by John Bura on 2016-01-10.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var block0 = SKSpriteNode?()
var block1 = SKSpriteNode?()
var block2 = SKSpriteNode?()
var block3 = SKSpriteNode?()

var lblMain = SKLabelNode?()
var lblTimer = SKLabelNode?()
var lblScore = SKLabelNode?()

var touchedNode = SKNode?()

var touchLocation = CGPoint?()

var blockSize = CGSize(width: 50, height: 50)

var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)

var greenColorCustom = UIColor.greenColor()
var orangeColorCustom = UIColor.orangeColor()
var blueColorCustom = UIColor.blueColor()
var redColorCustom = UIColor.redColor()
var purpleColorCustom = UIColor.purpleColor()

var colorArray = ["Green", "Orange", "Blue", "Red"]
var colorSelection = 0

var isCollecting = true
var isComplete = false

var countDownTimer = 12

var score = 0

var amountOfBlocksToSpawn = 7

var flashTime = 2.0


//
class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        self.backgroundColor = offWhiteColor
        resetGameVariablesOnStart()
        
        spawnBlocksWithLoop()
        
        spawnLblMain()
        spawnLblTimer()
        spawnLblScore()
        
        randomizeColor()
        displayColorsOnStart()
        flashTimerLogic()
        countDownTimerLogic()
        
    }
    
    func resetGameVariablesOnStart(){
        isCollecting = true
        isComplete = false
        
        countDownTimer = 12
        
        score = 0
        
        lblMain?.fontSize = 50
    }
    
    func randomizeColor(){
        colorSelection = Int(arc4random_uniform(4))
        lblMain?.fontSize = 55
        lblMain?.text = "Select \(colorArray[colorSelection]) blocks"
    }
    
    func displayColorsOnStart(){
        self.enumerateChildNodesWithName("block0Name", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.color = greenColorCustom
            }
        })
        
        self.enumerateChildNodesWithName("block1Name", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.color = orangeColorCustom
            }
        })
        
        self.enumerateChildNodesWithName("block2Name", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.color = blueColorCustom
            }
        })
        
        self.enumerateChildNodesWithName("block3Name", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.color = redColorCustom
            }
        })
    }
    
    func setBlockColorsToBlack(){
        self.enumerateChildNodesWithName("block0Name", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.color = offBlackColor
            }
        })
        
        self.enumerateChildNodesWithName("block1Name", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.color = offBlackColor
            }
        })
        
        self.enumerateChildNodesWithName("block2Name", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.color = offBlackColor
            }
        })
        
        self.enumerateChildNodesWithName("block3Name", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.color = offBlackColor
            }
        })
    }

    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        for touch in touches {
            touchLocation = touch.locationInNode(self)
            
            touchRightBlockLogic()
        }
    }
    
    func touchRightBlockLogic(){
        touchedNode = nodeAtPoint(touchLocation!)
        
        if touchedNode!.name == "block0Name"{
            if colorSelection == 0{
                touchedNode?.removeFromParent()
                updateScore()
            }
            
            if colorSelection != 0{
                gameOverLogic()
            }
        }
        if touchedNode!.name == "block1Name"{
            if colorSelection == 1{
                touchedNode?.removeFromParent()
                updateScore()
            }
            
            if colorSelection != 1{
                gameOverLogic()
            }
        }
        if touchedNode!.name == "block2Name"{
            if colorSelection == 2{
                touchedNode?.removeFromParent()
                updateScore()
            }
            
            if colorSelection != 2{
                gameOverLogic()
            }
        }
        if touchedNode!.name == "block3Name"{
            if colorSelection == 3{
                touchedNode?.removeFromParent()
                updateScore()
            }
            
            if colorSelection != 3{
                gameOverLogic()
            }
        }
        
        
        
     
        
        
    }
    
    func updateScore(){
        score = score + 1
        lblScore?.text = "Score: \(score)"
    }
    
    func spawnBlocksWithLoop(){
        for _ in 1...amountOfBlocksToSpawn{
            spawnBlock0()
            spawnBlock1()
            spawnBlock2()
            spawnBlock3()
        }
    }
    
    func spawnBlock0(){
        let randomX = Int(arc4random_uniform(500) + 300)
        let randomY = Int(arc4random_uniform(600))
        
        block0 = SKSpriteNode(color: offBlackColor, size: blockSize)
        block0?.position = CGPoint(x: randomX, y: randomY)
        block0?.name = "block0Name"
        
        self.addChild(block0!)
    }
    
    func spawnBlock1(){
        let randomX = Int(arc4random_uniform(500) + 300)
        let randomY = Int(arc4random_uniform(600))
        
        block1 = SKSpriteNode(color: offBlackColor, size: blockSize)
        block1?.position = CGPoint(x: randomX, y: randomY)
        block1?.name = "block1Name"
        
        self.addChild(block1!)
    }
    
    func spawnBlock2(){
        let randomX = Int(arc4random_uniform(500) + 300)
        let randomY = Int(arc4random_uniform(600))
        
        block2 = SKSpriteNode(color: offBlackColor, size: blockSize)
        block2?.position = CGPoint(x: randomX, y: randomY)
        block2?.name = "block2Name"
        
        self.addChild(block2!)
    }
    
    func spawnBlock3(){
        let randomX = Int(arc4random_uniform(500) + 300)
        let randomY = Int(arc4random_uniform(600))
        
        block3 = SKSpriteNode(color: offBlackColor, size: blockSize)
        block3?.position = CGPoint(x: randomX, y: randomY)
        block3?.name = "block3Name"
        
        self.addChild(block3!)
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontColor = purpleColorCustom
        lblMain?.fontSize = 100
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 250)
        lblMain?.text = "Start!"
        
        self.addChild(lblMain!)
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontColor = purpleColorCustom
        lblScore?.fontSize = 50
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 350)
        lblScore?.text = "Score: \(score)"
        
        self.addChild(lblScore!)
    }
    
    func spawnLblTimer(){
        lblTimer = SKLabelNode(fontNamed: "Futura")
        lblTimer?.fontColor = purpleColorCustom
        lblTimer?.fontSize = 150
        lblTimer?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 250)
        lblTimer?.text = "\(countDownTimer - 2)"
        
        self.addChild(lblTimer!)
    }
    
    func flashTimerLogic(){
        let  wait = SKAction.waitForDuration(flashTime)
        let countDown = SKAction.runBlock{
            self.setBlockColorsToBlack()
        }
        
        let sequence = SKAction.sequence([wait, countDown])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    
    func countDownTimerLogic(){
        let  wait = SKAction.waitForDuration(1.0)
        let countDown = SKAction.runBlock{
            
            if isCollecting == true{
                countDownTimer = countDownTimer - 1
            }
            
            if isCollecting == false && isComplete == true{
                countDownTimer = 0
            }
            
            if countDownTimer <= 10 && isComplete == false{
                lblTimer?.text = "\(countDownTimer)"
            }
            
            if countDownTimer <= 0{
                self.gameOverLogic()
            }
        }
        
        let sequence = SKAction.sequence([wait, countDown])
        self.runAction(SKAction.repeatAction(sequence, count: countDownTimer))
        
    }
    
    func gameOverLogic(){
        isCollecting = false
        isComplete = true
        
        lblMain?.fontSize = 100
        lblMain?.text = "Game Over"
        lblTimer?.text = ""
        
        resetTheGame()
    }
    
    func resetTheGame(){
        let wait = SKAction.waitForDuration(5.0)
        let theGameScene = GameScene(size: self.size)
        theGameScene.scaleMode = SKSceneScaleMode.AspectFill
        let transition = SKTransition.doorsOpenVerticalWithDuration(1.0)
        
        let changeScene = SKAction.runBlock{
            self.scene!.view?.presentScene(theGameScene, transition: transition)
        }
        
        let sequence = SKAction.sequence([wait, changeScene])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
        
    }
    
    func deleteAllBlocks(){
        if isComplete == true{
            self.enumerateChildNodesWithName("block0Name", usingBlock: { node, stop in
                if let sprite = node as? SKSpriteNode{
                    sprite.removeFromParent()
                }
            })
            self.enumerateChildNodesWithName("block1Name", usingBlock: { node, stop in
                if let sprite = node as? SKSpriteNode{
                    sprite.removeFromParent()
                }
            })
            self.enumerateChildNodesWithName("block2Name", usingBlock: { node, stop in
                if let sprite = node as? SKSpriteNode{
                    sprite.removeFromParent()
                }
            })
            
            self.enumerateChildNodesWithName("block3Name", usingBlock: { node, stop in
                if let sprite = node as? SKSpriteNode{
                sprite.removeFromParent()
                }
            })
        }
    }
    
    
   //
    override func update(currentTime: CFTimeInterval) {
       deleteAllBlocks()
    }
}
