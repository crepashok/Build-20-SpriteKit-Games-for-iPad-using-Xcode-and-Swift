//
//  GameScene.swift
//  Random block Collector
//
//  Created by John Bura on 2016-01-10.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var block = SKSpriteNode?()

var touchedNode = SKNode?()

var lblMain = SKLabelNode?()
var lblTimer = SKLabelNode?()
var lblScore = SKLabelNode?()

var blockSize = CGSize(width: 50, height: 50)

var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
var orangeColorCustom = UIColor.orangeColor()

var isCollecting = true
var isComplete = false

var collectingTimer = 7

var score = 0

var amountOfBlocksToSpawn = 25

var touchLocation = CGPoint?()

//
class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
       self.backgroundColor = offWhiteColor
        resetVariablesOnStart()
        
        spawnLblMain()
        spawnLblScore()
        spawnLblTimer()
        
        countDownTimer()
        
        spawnMultipleBlocks()
    }
    
    func resetVariablesOnStart(){
        isCollecting = true
        isComplete = false
        
        collectingTimer = 7
        
        score = 0
        
        amountOfBlocksToSpawn = 25
    }
    
    func spawnMultipleBlocks(){
        for _ in 1...amountOfBlocksToSpawn{
            spawnBlock()
        }
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
     
        
        for touch in touches {
            touchLocation = touch.locationInNode(self)
            
            if isCollecting == true{
                removeBlocks()
            }
        }
    }
    
    func removeBlocks(){
        touchedNode = nodeAtPoint(touchLocation!)
        
        if touchedNode?.name == "blockName" {
            updateScore()
            touchedNode?.removeFromParent()
        }
    }
    
    func updateScore(){
        score = score + 1
        lblScore?.text = "Score: \(score)"
    }
    
    func spawnBlock(){
        let randomX = Int(arc4random_uniform(500) + 300)
        let randomY = Int(arc4random_uniform(600))
        
        block = SKSpriteNode(color: orangeColorCustom, size: blockSize)
        block?.position = CGPoint(x: randomX, y: randomY)
        block?.name = "blockName"
        
        self.addChild(block!)
        
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontColor = offBlackColor
        lblMain?.fontSize = 80
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 220)
        
        lblMain?.text = "Collect Blocks!"
        
        self.addChild(lblMain!)
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontColor = offBlackColor
        lblScore?.fontSize = 50
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 350)
        
        lblScore?.text = "Score: \(score)"
        
        self.addChild(lblScore!)
    }
    
    func spawnLblTimer(){
        lblTimer = SKLabelNode(fontNamed: "Futura")
        lblTimer?.fontColor = offBlackColor
        lblTimer?.fontSize = 120
        lblTimer?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 250)
        
        lblTimer?.text = "5"
        
        self.addChild(lblTimer!)
    }
    
    func countDownTimer(){
        let wait = SKAction.waitForDuration(1.0)
        let countDown = SKAction.runBlock{
            collectingTimer = collectingTimer - 1
            
            if collectingTimer <= 5{
                lblTimer?.text = "\(collectingTimer)"
            }
            
            if collectingTimer <= 1{
                lblTimer?.fontColor = UIColor.redColor()
            }
            
            if collectingTimer <= 0{
                self.gameOverLogic()
            }
            
        }
        
        let sequence = SKAction.sequence([wait, countDown])
        self.runAction(SKAction.repeatAction(sequence, count: collectingTimer))
    }
   
    func gameOverLogic(){
        isCollecting = false
        isComplete = true
        
        self.backgroundColor = offBlackColor
        
        lblMain?.fontColor = orangeColorCustom
        lblScore?.fontColor = orangeColorCustom
        lblTimer?.fontColor = orangeColorCustom
        
        resetTheGame()
    }
    
    func resetTheGame(){
        let wait = SKAction.waitForDuration(5.0)
        let theGameScene = GameScene(size: self.size)
        theGameScene.scaleMode = SKSceneScaleMode.AspectFill
        let transition = SKTransition.crossFadeWithDuration(0.5)
        
        let changeScene = SKAction.runBlock{
            self.scene!.view?.presentScene(theGameScene, transition: transition)
        }
        
        let sequence = SKAction.sequence([wait, changeScene])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    
    func removeExtraBlocks(){
        if isComplete == true{
            self.enumerateChildNodesWithName("blockName", usingBlock: { node, stop in
                if let sprite = node as? SKSpriteNode{
                    sprite.removeFromParent()
                }
            })
        }
    }
    
    //
    override func update(currentTime: CFTimeInterval) {
        removeExtraBlocks()
    }
}
