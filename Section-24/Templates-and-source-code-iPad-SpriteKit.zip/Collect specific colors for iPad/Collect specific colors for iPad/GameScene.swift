//
//  GameScene.swift
//  Collect specific colors for iPad
//
//  Created by John Bura on 2016-01-10.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var block0 = SKSpriteNode?()
var block1 = SKSpriteNode?()

var touchedNode = SKNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()
var lblTimer = SKLabelNode?()

var blockSize = CGSize(width: 40, height: 40)

var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var blueColorCustom = UIColor(red: 0.0, green: 0.7, blue: 1.0, alpha: 1.0)
var orangeColorCustom = UIColor.orangeColor()

var isBeingPlaced = false
var isCollecting = false
var isComplete = false

var startTimerVar = 5
var placingTimerVar = 4
var collectingTimerVar = 5

var score = 0

var touchLocation = CGPoint?()

//
class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
       self.backgroundColor = offBlackColor
        resetGameVariablesOnStart()
        spawnLblMain()
        spawnLblScore()
        spawnLblTimer()
        
        starterTimer()
    }
    
    func resetGameVariablesOnStart(){
        isBeingPlaced = false
        isCollecting = false
        isComplete = false
        
        startTimerVar = 5
        placingTimerVar = 4
        collectingTimerVar = 5
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
      
        
        for touch in touches {
            touchLocation = touch.locationInNode(self)
            
            correctGameStateTouchLogic()
        }
    }
    
    func correctGameStateTouchLogic(){
        if isBeingPlaced == true{
            spawnBlock0()
            spawnBlock1()
            updateScore()
        }
        
        if isCollecting == true{
            touchedNode = nodeAtPoint(touchLocation!)
            touchedCorrectNode()
        }
    }
    
    func touchedCorrectNode(){
        if touchedNode?.name == "block0Name"{
            touchedNode?.removeFromParent()
            updateScore()
        }
        
        if touchedNode?.name == "block1Name"{
            gameOverLogic()
        }
    }
    
    func updateScore(){
        score = score + 1
        lblScore?.text = "Score: \(score)"
    }

    //
    func spawnBlock0(){
        block0 = SKSpriteNode(color: offWhiteColor, size: blockSize)
        block0?.position = CGPoint(x: (touchLocation?.x)! - 50, y: (touchLocation?.y)!)
        block0?.name = "block0Name"
        
        self.addChild(block0!)
    }
    
    func spawnBlock1(){
        block1 = SKSpriteNode(color: offWhiteColor, size: blockSize)
        block1?.position = CGPoint(x: (touchLocation?.x)! + 50, y: (touchLocation?.y)!)
        block1?.name = "block1Name"
        
        self.addChild(block1!)
    }
    //
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontColor = offWhiteColor
        lblMain?.fontSize = 110
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 220)
        lblMain?.text = "Ready!"
        
        self.addChild(lblMain!)
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontColor = offWhiteColor
        lblScore?.fontSize = 40
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 350)
        lblScore?.text = "Score: \(score)"
        self.addChild(lblScore!)
    }
    
    func spawnLblTimer(){
        lblTimer = SKLabelNode(fontNamed: "Futura")
        lblTimer?.fontColor = offWhiteColor
        lblTimer?.fontSize = 90
        lblTimer?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 250)
        lblTimer?.text = "0"
        
        self.addChild(lblTimer!)
    }
    
    func starterTimer(){
        let wait = SKAction.waitForDuration(1.0)
        let countDownTimer = SKAction.runBlock{
            startTimerVar = startTimerVar - 1
            
          
            
            if startTimerVar <= 3{
                lblMain?.fontSize = 150
                lblMain?.text = "Set \(startTimerVar)"
            }
            if startTimerVar <= 0{
                lblMain?.fontSize = 175
                lblMain?.text = "Go!"
                lblMain?.alpha = 0.5
            
                self.setIsPlacingLogic()
                self.isPlacingTimer()
            }
        }
        
        let sequence = SKAction.sequence([wait, countDownTimer])
        let starTimerTemp = startTimerVar + 1
        self.runAction(SKAction.repeatAction(sequence, count: startTimerVar))
    }
    
    func setIsPlacingLogic(){
        isBeingPlaced = true
        isCollecting = false
        isComplete = false
    }
    
    func isPlacingTimer(){
        let wait = SKAction.waitForDuration(1.0)
        let countDownTimer = SKAction.runBlock{
            placingTimerVar = placingTimerVar - 1
            
            lblMain?.fontSize = 90
            lblMain?.text = "Place Blocks!"
            
            if placingTimerVar <= 3 && placingTimerVar >= 0{
                lblTimer?.text = "\(placingTimerVar)"
            }
            
            if placingTimerVar < 0{
                self.setIsCollectingLogic()
                 self.backgroundColor = offWhiteColor
                lblMain?.alpha = 1.0
                lblMain?.fontColor = offBlackColor
                lblMain?.zPosition = 1
                
                lblScore?.fontColor = orangeColorCustom
                lblScore?.zPosition = 1
                
                lblTimer?.fontColor = offBlackColor
                lblTimer?.zPosition = 1
                
            }
        }
        
        let sequence = SKAction.sequence([wait, countDownTimer])
        let placingTimerTemp = placingTimerVar + 1
        self.runAction(SKAction.repeatAction(sequence, count: placingTimerTemp))
    }
    
    func setIsCollectingLogic(){
        isBeingPlaced = false
        isCollecting = true
        isComplete = false
        
        isCollectingTimer()
    }
    
    func isCollectingTimer(){
        let wait = SKAction.waitForDuration(1.0)
        let countDownTimer = SKAction.runBlock{
            collectingTimerVar = collectingTimerVar - 1
            
    
            lblMain?.fontSize = 50
            lblMain?.text = "Collect Orange Blocks!"

            if collectingTimerVar <= 5 && isCollecting == true{
                lblTimer?.text = "\(collectingTimerVar)"
            }
            
            if collectingTimerVar <= 0{
                self.gameOverLogic()
            }
        }
        
        let sequence = SKAction.sequence([wait, countDownTimer])
        self.runAction(SKAction.repeatAction(sequence, count: collectingTimerVar))
    }
    
    func gameOverLogic(){
        isBeingPlaced = false
        isCollecting = false
        isComplete = true
        
        self.backgroundColor = offBlackColor
        
        
        lblMain?.text = "Game Over"
        lblMain?.fontSize = 90
        lblMain?.fontColor = offWhiteColor
        
        lblScore?.fontColor = offWhiteColor
        
        lblTimer?.fontColor = offWhiteColor
        
        resetTheGame()
    }
    
    func resetTheGame(){
        let wait = SKAction.waitForDuration(4.0)
        
        let theGameScene = GameScene(size: self.size)
        theGameScene.scaleMode = SKSceneScaleMode.AspectFill
        
        let transition = SKTransition.doorwayWithDuration(0.5)
        
        let sceneChange = SKAction.runBlock{
            self.scene!.view?.presentScene(theGameScene, transition: transition)
        
        }
        
        let sequence = SKAction.sequence([wait, sceneChange])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    //
    func changeBlockColor(){
        if isCollecting == true{
            self.enumerateChildNodesWithName("block0Name", usingBlock: {node, stop in
                if let sprite = node as? SKSpriteNode{
                    sprite.color = orangeColorCustom
                }
            })
            
            self.enumerateChildNodesWithName("block1Name", usingBlock: {node, stop in
                if let sprite = node as? SKSpriteNode{
                    sprite.color = blueColorCustom
                }
            })
            
        }
        
        if isComplete == true{
            self.enumerateChildNodesWithName("block0Name", usingBlock: {node, stop in
                if let sprite = node as? SKSpriteNode{
                    sprite.removeFromParent()
                }
            })
            
            self.enumerateChildNodesWithName("block1Name", usingBlock: {node, stop in
                if let sprite = node as? SKSpriteNode{
                    sprite.removeFromParent()
                }
            })
        }
    }
    
   //
    override func update(currentTime: CFTimeInterval) {
       changeBlockColor()
    }
}
