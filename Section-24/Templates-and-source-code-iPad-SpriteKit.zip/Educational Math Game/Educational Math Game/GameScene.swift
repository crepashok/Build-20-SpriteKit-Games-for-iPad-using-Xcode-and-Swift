//
//  GameScene.swift
//  Educational Math Game
//
//  Created by John Bura on 2016-01-14.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var button0 = SKSpriteNode?()
var button1 = SKSpriteNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()

var touchedNode = SKNode?()

var colorArray = ["Green","Orange","Red","Blue","Purple","Pink","Yellow"]
var randomColor = 0
var buttonCorrect = 0

var correctColor = UIColor?()
var incorrectColor = UIColor?()
var offBlackColor = UIColor(red: 0.1, green: 0.1, blue: 0.1, alpha: 1.0)
var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)

var buttonSize = CGSize(width: 220, height: 150)

var score = 0

//
class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        self.backgroundColor = offBlackColor
        
        spawnLblMain()
        spawnLblScore()
        spawnButton0()
        spawnButton1()
        randomizeColor()
    }
    
    func randomizeColor(){
        randomColor = Int(arc4random_uniform(7))
        buttonCorrect = Int(arc4random_uniform(2))
        
        lblMain?.text = "\(colorArray[randomColor])"
        chooseProperButton()
    }
    
    func chooseProperButton(){
        if randomColor == 0{
            correctColor = UIColor.greenColor()
            incorrectColor = UIColor.redColor()
        }
        if randomColor == 1{
            correctColor = UIColor.orangeColor()
            incorrectColor = UIColor.blueColor()
        }
        if randomColor == 2{
            correctColor = UIColor.redColor()
            incorrectColor = UIColor.lightGrayColor()
        }
        if randomColor == 3{
            correctColor = UIColor.blueColor()
            incorrectColor = UIColor.redColor()
        }
        if randomColor == 4{
            correctColor = UIColor.purpleColor()
            incorrectColor = UIColor.yellowColor()
        }
        if randomColor == 5{
            correctColor = UIColor(red: 1.0, green: 0.5, blue: 0.5, alpha: 1.0)
            incorrectColor = UIColor.greenColor()
        }
        if randomColor == 6{
            correctColor = UIColor.yellowColor()
            incorrectColor = UIColor.purpleColor()
        }
        
        if buttonCorrect == 0{
            button0?.color = correctColor!
            button1?.color = incorrectColor!
        }
        
        if buttonCorrect == 1{
            button0?.color = incorrectColor!
            button1?.color = correctColor!
        }
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontColor = offWhiteColor
        lblMain?.fontSize = 120
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 150)
        
        lblMain?.text = "Color"
        
        self.addChild(lblMain!)
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontColor = offWhiteColor
        lblScore?.fontSize = 50
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 350)
        
        lblScore?.text = "Score: \(score)"
        
        self.addChild(lblScore!)
    }
    
    func spawnButton0(){
        button0 = SKSpriteNode(color: offWhiteColor, size: buttonSize)
        button0?.position = CGPoint(x: CGRectGetMidX(self.frame) - 150, y: CGRectGetMidY(self.frame) - 75)
        button0?.name = "button0Name"
        
        self.addChild(button0!)
    }
    
    func spawnButton1(){
        button1 = SKSpriteNode(color: offWhiteColor, size: buttonSize)
        button1?.position = CGPoint(x: CGRectGetMidX(self.frame) + 150, y: CGRectGetMidY(self.frame) - 75)
        button1?.name = "button1Name"
        
        self.addChild(button1!)
    }
    //
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {

        
        for touch in touches {
            let location = touch.locationInNode(self)
          
            
            touchedNode = nodeAtPoint(location)
            correctButtonLogic()
        }
    }
    
    func correctButtonLogic(){
        if buttonCorrect == 0{
           if touchedNode?.name == "button0Name"{
                randomizeColor()
                score = score + 1
                updateScore()
            }
            if touchedNode?.name == "button1Name"{
                randomizeColor()
            }
            
        }
        if buttonCorrect == 1{
            if touchedNode?.name == "button1Name"{
                score = score + 1
                randomizeColor()
                updateScore()
            }
            if touchedNode?.name == "button0Name"{
                randomizeColor()
            }
        }
        
    }
    
    func updateScore(){
        lblScore?.text = "Score: \(score)"
    }
   
    //
    override func update(currentTime: CFTimeInterval) {
   
    }
}
