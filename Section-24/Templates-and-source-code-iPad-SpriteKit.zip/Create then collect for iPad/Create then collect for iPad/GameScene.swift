//
//  GameScene.swift
//  Create then collect for iPad
//
//  Created by John Bura on 2016-01-09.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var block = SKSpriteNode?()

var touchedNode = SKNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()
var lblTimer = SKLabelNode?()

var blockSize = CGSize(width: 60, height: 60)

var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var greenColorCustom = UIColor.greenColor()
var orangeColorCustom = UIColor.orangeColor()

var isBeingPlaced = true
var isCollecting = false
var isComplete = false

var countDownTimerPlaced = 7
var countDownTimerCollected = 5

var score = 0

var touchLocation = CGPoint?()



//
class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        self.backgroundColor = offBlackColor
        
        resetGameVariablesOnStart()
        
       spawnLblMain()
        spawnLblScore()
        spawnLblTimer()
        
        countDownTimerIsPlacing()
    }
    
    func resetGameVariablesOnStart(){
        isBeingPlaced = true
        isCollecting = false
        isComplete = false
        
        countDownTimerPlaced = 7
        countDownTimerCollected = 5
        
        score = 0
        
        lblMain?.fontColor = offWhiteColor
        lblScore?.fontColor = offWhiteColor
        lblTimer?.fontColor = offWhiteColor
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {

        for touch in touches {
            touchLocation = touch.locationInNode(self)
            
            if isBeingPlaced == true && isCollecting == false{
                spawnBlock()
                addToScore()
                score = score + 1
            }
            
            if isCollecting == true && isBeingPlaced == false{
                touchedNode = nodeAtPoint(touchLocation!)
                
                if touchedNode?.name == "blockName"{
                 score = score + 1
                }
                
                touchedNode?.removeFromParent()
                addToScore()
            }
        }
    }
    
    func addToScore(){
        
        lblScore?.text = "Score: \(score)"
    }
    
    func spawnBlock(){
        block = SKSpriteNode(color: greenColorCustom, size: blockSize)
        block?.position.x = (touchLocation?.x)!
        block?.position.y = (touchLocation?.y)!
        block?.name = "blockName"
        
        self.addChild(block!)
        
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontColor = offWhiteColor
        lblMain?.fontSize = 90
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 250)
        
        lblMain?.text = "Place Blocks!"
        
        self.addChild(lblMain!)
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontColor = offWhiteColor
        lblScore?.fontSize = 50
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 350)
        
        lblScore?.text = "Score: \(score)"
        
        self.addChild(lblScore!)
    }
    
    func spawnLblTimer(){
        lblTimer = SKLabelNode(fontNamed: "Futura")
        lblTimer?.fontColor = offWhiteColor
        lblTimer?.fontSize = 100
        lblTimer?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 250)
        
        lblTimer?.text = "\(countDownTimerPlaced - 2)"
        
        self.addChild(lblTimer!)
    }
    
    func countDownTimerIsPlacing(){
        let wait = SKAction.waitForDuration(1.0)
        let countDown = SKAction.runBlock{
            countDownTimerPlaced = countDownTimerPlaced - 1

            lblTimer?.zPosition = 1
            
            if countDownTimerPlaced <= 5{
                lblTimer?.text = "\(countDownTimerPlaced)"
            }
            
            if countDownTimerPlaced <= 0{
                self.countDownTimerIsCollecting()
                isBeingPlaced = false
                isCollecting = true
            }
        }
        
        let sequnce = SKAction.sequence([wait, countDown])
        self.runAction(SKAction.repeatAction(sequnce, count: countDownTimerPlaced))
    }
    //
    func countDownTimerIsCollecting(){
        let wait = SKAction.waitForDuration(1.0)
        let countDown = SKAction.runBlock{
            countDownTimerCollected = countDownTimerCollected - 1
            
            
            
            lblMain?.fontSize = 80
            lblMain?.text = "Collect Blocks!"
            lblMain?.fontColor = orangeColorCustom
            lblTimer?.fontColor = orangeColorCustom
            lblScore?.fontColor = orangeColorCustom
            
            
            if countDownTimerCollected <= 3{
                lblTimer?.text = "\(countDownTimerCollected)"
            }
            
            if countDownTimerCollected <= 0{
                isComplete = true
                self.gameOverLogic()
            }
        }
        
        let sequnce = SKAction.sequence([wait, countDown])
        self.runAction(SKAction.repeatAction(sequnce, count: countDownTimerCollected))
    }
    
    func gameOverLogic(){
        isBeingPlaced = false
        isCollecting = false
        
        lblMain?.text = "Game Over!"
        
        lblTimer?.text = "Try Again!"
        
        resetTheGame()
    }
    //
    func resetTheGame(){
        let wait = SKAction.waitForDuration(4.0)
        let gameScene = GameScene(size: self.size)
        let transition = SKTransition.doorwayWithDuration(0.5)
        
        gameScene.scaleMode = SKSceneScaleMode.AspectFill
        
        let changeScene = SKAction.runBlock{
            self.scene!.view?.presentScene(gameScene, transition: transition)
        }
        
        let sequence = SKAction.sequence([wait, changeScene])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    
    
    
    
    override func update(currentTime: CFTimeInterval) {
        if isCollecting == true{
            self.enumerateChildNodesWithName("blockName") {
                node, stop in
                if let sprite = node as? SKSpriteNode {
                    sprite.color = UIColor.orangeColor()
                }
            }
        }
    }
}
