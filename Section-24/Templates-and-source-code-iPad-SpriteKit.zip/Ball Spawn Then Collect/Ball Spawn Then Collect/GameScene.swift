//
//  GameScene.swift
//  Ball Spawn Then Collect
//
//  Created by John Bura on 2015-12-14.
//  Copyright (c) 2015 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var block = SKSpriteNode?()
var floor = SKSpriteNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()

var blockColor = UIColor?()

var isSpawning = true
var isCollecting = false
var canComplete = false
var logicVar = false

var baseColor : CGFloat = 0.5

var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)

var touchLocation = CGPoint?()

var score = 0

var countDownTimerVar = 6
var topCountDownTimer = 5

var touchedNode = SKNode?()

//
class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        self.backgroundColor = offBlackColor
        
        let physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
        self.physicsBody = physicsBody
        
        spawnFloor()
        spawnLblMain()
        spawnLblScore()
        countDownTimer()
        resetVariablesOnStart()
       
    }
    
    func resetVariablesOnStart(){
        isSpawning = true
        isCollecting = false
        canComplete = false
        logicVar = false
        
        score = 0
        
        countDownTimerVar = 6
        topCountDownTimer = 5
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
       
        for touch in touches {
             touchLocation = touch.locationInNode(self)
            
            touchedNode = nodeAtPoint(touchLocation!)
            
            if isSpawning == true{
                spawnBlock()
            }
            
            if isCollecting == true{
                collectBlock()
            }
            

        }
    }
   
    override func update(currentTime: CFTimeInterval) {

        if canComplete == true{
            lblMain?.fontSize = 90
            lblMain?.text = "Game Over"
        }
        
    }
    
    func spawnFloor(){
        floor = SKSpriteNode(color: offWhiteColor, size: CGSize(width: self.frame.width, height: 250))
        floor?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMinY(self.frame))
        
        floor?.physicsBody = SKPhysicsBody(rectangleOfSize: floor!.size)
        floor?.physicsBody?.affectedByGravity = false
        floor?.physicsBody?.dynamic = false
        
        
        self.addChild(floor!)
    }
    //
    func spawnBlock(){
        
        var red = Int(arc4random_uniform(255)) / 2
        var green = Int(arc4random_uniform(255)) / 2
        var blue = Int(arc4random_uniform(255)) / 2
        
        blockColor = UIColor(red: (CGFloat(red) / 255) + baseColor, green: (CGFloat(green) / 255) + baseColor, blue: (CGFloat(blue) / 255) + baseColor, alpha: 1.0)
        
        block = SKSpriteNode(color: blockColor!, size: CGSize(width: 130, height: 130))
        block?.position.x = (touchLocation?.x)!
        block?.position.y = (touchLocation?.y)!

        block?.physicsBody = SKPhysicsBody(rectangleOfSize: block!.size)
        block?.physicsBody?.affectedByGravity = true
        
        score = score + 1
        updateScore()
        
        self.addChild(block!)
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontSize = 350
        lblMain?.fontColor = offWhiteColor
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 350)
        lblMain?.text = "Start!"
        
        self.addChild(lblMain!)
        
    }
    //
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontSize = 100
        lblScore?.fontColor = offBlackColor
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: 30)
        lblScore?.text = "Score 0"
        
        self.addChild(lblScore!)
    }
    
    func collectBlock(){
        touchedNode!.removeFromParent()
        
        score = score + 1
        updateScore()
    }
    
    func updateScore(){
        lblScore?.text = "Score: \(score)"
    }
    //
    func countDownTimer(){
        
        let wait = SKAction.waitForDuration(1.0)
        let countDown = SKAction.runBlock{
            countDownTimerVar--
            
            if countDownTimerVar <= 0{
                countDownTimerVar = topCountDownTimer
                if isSpawning == true && isCollecting == false{
                    isSpawning = false
                    isCollecting = true
                }
                
                if isSpawning == false && isCollecting == true && canComplete == false && logicVar == true{
                    isSpawning = false
                    isCollecting = false
                    canComplete = true
                    
                    self.waitThenMoveToTitleScene()
                }
                
                logicVar = true
                
            }
            if canComplete == false{
                lblMain?.text = "\(countDownTimerVar)"
            }
        }
    
            let sequence = SKAction.sequence([wait, countDown])
            self.runAction(SKAction.repeatActionForever(sequence))
    }
    
    func waitThenMoveToTitleScene(){
        let wait = SKAction.waitForDuration(2.0)
        let transition = SKAction.runBlock{
              self.view?.presentScene(TitleScene(), transition: SKTransition.crossFadeWithDuration(1.0))
        }
        
        let sequence = SKAction.sequence([wait, transition])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    
}
