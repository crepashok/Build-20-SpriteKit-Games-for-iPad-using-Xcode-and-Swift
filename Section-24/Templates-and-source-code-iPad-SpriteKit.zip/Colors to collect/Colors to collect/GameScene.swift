//
//  GameScene.swift
//  Colors to collect
//
//  Created by John Bura on 2016-01-06.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var touchLocation = CGPoint?()

var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)

var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var orangeColor = UIColor.orangeColor()
var blueColor = UIColor(red: 0.0, green: 0.7, blue: 1.0, alpha: 1.0)

var colorSelection = 0

var player = SKSpriteNode?()
var fallingBlock = SKSpriteNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()

var playerSize = CGSize(width: 50, height: 50)
var fallingBlockSize = CGSize(width: 40, height: 40)

var fallingBlockSpeed = 2.5
var spawnTimeFallingBlock = 1.5

var score = 0

var isAlive = true

struct physicsCategory {
    static let player : UInt32 = 1
    static let fallingBlock : UInt32 = 2
}

//
class GameScene: SKScene, SKPhysicsContactDelegate {
    override func didMoveToView(view: SKView) {
        self.backgroundColor = offBlackColor
        
        physicsWorld.contactDelegate = self
        
        spawnPlayer()
        fallingBlockSpawnTimer()
        spawnLblMain()
        spawnLblScore()
        resetVariablesOnStart()
    }
    
    func resetVariablesOnStart(){
         score = 0
        
         isAlive = true
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
 
        
        for touch in touches {
            touchLocation = touch.locationInNode(self)

        }
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches {
            touchLocation = touch.locationInNode(self)
            
            if isAlive == true{
                player?.position.x = (touchLocation?.x)!
            }
            if isAlive == false{
                player?.position.x = -300
            }
        }
    }
   
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches {
            touchLocation = touch.locationInNode(self)
            
            colorSelection = colorSelection + 1
            
            if colorSelection == 3{
                colorSelection = 0
            }

            
            if colorSelection == 0{
                player?.color = offWhiteColor
            }
            if colorSelection == 1{
                player?.color = orangeColor
            }
            if colorSelection == 2{
                player?.color = blueColor
            }
            
            
        }
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontSize = 100
        lblMain?.fontColor = offWhiteColor
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 200)
        
        lblMain?.text = "Start!"
        
        self.addChild(lblMain!)
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontSize = 50
        lblScore?.fontColor = offWhiteColor
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: 30)
        lblScore?.text = "Score: \(score)"
        
        self.addChild(lblScore!)
    }
    
    func spawnPlayer(){
        player = SKSpriteNode(color: offWhiteColor, size: playerSize)
        player?.position = CGPoint(x: CGRectGetMidX(self.frame), y: 130)
        
        player?.physicsBody = SKPhysicsBody(rectangleOfSize: (player?.size)!)
        player?.physicsBody?.affectedByGravity = false
        player?.physicsBody?.categoryBitMask = physicsCategory.player
        player?.physicsBody?.contactTestBitMask = physicsCategory.fallingBlock
        player?.physicsBody?.dynamic = false
        player?.physicsBody?.allowsRotation = false
        player?.name = "player"

        
        self.addChild(player!)
    }
    
    func spawnFallingBlocks(){
        
        let randomXPosition = Int(arc4random_uniform(700) + 200)
        let colorOfBlock = Int(arc4random_uniform(3))
        
        fallingBlock = SKSpriteNode(color: offWhiteColor, size: fallingBlockSize)
        fallingBlock?.position = CGPoint(x: randomXPosition, y: 1000)
        
        fallingBlock?.physicsBody = SKPhysicsBody(rectangleOfSize: (fallingBlock?.size)!)
        fallingBlock?.physicsBody?.affectedByGravity = false
        fallingBlock?.physicsBody?.categoryBitMask = physicsCategory.fallingBlock
        fallingBlock?.physicsBody?.contactTestBitMask = physicsCategory.player
        fallingBlock?.physicsBody?.dynamic = true
        fallingBlock?.physicsBody?.allowsRotation = false
        fallingBlock?.name = "fallingBlock0"
        
        if colorOfBlock == 0{
            fallingBlock?.color = offWhiteColor
            fallingBlock?.name = "fallingBlock0"
        }
        if colorOfBlock == 1{
            fallingBlock?.color = orangeColor
            fallingBlock?.name = "fallingBlock1"
        }
        if colorOfBlock == 2{
            fallingBlock?.color = blueColor
            fallingBlock?.name = "fallingBlock2"
        }
        
        var moveForward = SKAction.moveToY(-100, duration: fallingBlockSpeed)
        let destroy = SKAction.removeFromParent()
        
        if isAlive == false{
            moveForward = SKAction.moveToY(1500, duration: 0.1)
        }
        
        fallingBlock?.runAction(SKAction.sequence([moveForward, destroy]))
        
        self.addChild(fallingBlock!)
    }
    
    func fallingBlockSpawnTimer(){
        let spawnTimer = SKAction.waitForDuration(spawnTimeFallingBlock)
        let spawn = SKAction.runBlock{
            self.spawnFallingBlocks()
        }
        
        let sequence = SKAction.sequence([spawnTimer, spawn])
        
        self.runAction(SKAction.repeatActionForever(sequence))
        
        
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
        let firstBody : SKPhysicsBody = contact.bodyA
        let secondBody : SKPhysicsBody = contact.bodyB
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.fallingBlock) ||
            (firstBody.categoryBitMask == physicsCategory.fallingBlock) && (secondBody.categoryBitMask == physicsCategory.player)){
                
                fallingBlockCollsion(firstBody.node as! SKSpriteNode, secondBodyTemp: secondBody.node as! SKSpriteNode)
        }
    }
    //
    func fallingBlockCollsion(firstBodyTemp: SKSpriteNode, secondBodyTemp: SKSpriteNode){
        
        if firstBodyTemp.name == "player"{
            if colorSelection == 0 && secondBodyTemp.name == "fallingBlock0"{
                secondBodyTemp.removeFromParent()
                score = score + 1
                updateScore()
            }
            else if (colorSelection == 1 || colorSelection == 2) && secondBodyTemp.name == "fallingBlock0" {
                isAlive = false
                waitThenResetTheGame()
            }
            
            if colorSelection == 1 && secondBodyTemp.name == "fallingBlock1"{
                secondBodyTemp.removeFromParent()
                score = score + 1
                updateScore()
            }
            else if (colorSelection == 0 || colorSelection == 2) && secondBodyTemp.name == "fallingBlock1" {
                isAlive = false
                waitThenResetTheGame()
            }
            
            if colorSelection == 2 && secondBodyTemp.name == "fallingBlock2"{
                secondBodyTemp.removeFromParent()
                score = score + 1
                updateScore()
            }
            
            else if (colorSelection == 1 || colorSelection == 0) && secondBodyTemp.name == "fallingBlock2" {
                isAlive = false
                waitThenResetTheGame()
            }
        }
        
        if secondBodyTemp.name == "player"{
            if colorSelection == 0 && firstBodyTemp.name == "fallingBlock0"{
                secondBodyTemp.removeFromParent()
                score = score + 1
                updateScore()
            }
            else{
                isAlive = false
                waitThenResetTheGame()
            }
            
            if colorSelection == 1 && firstBodyTemp.name == "fallingBlock1"{
                secondBodyTemp.removeFromParent()
                score = score + 1
                updateScore()
            }
            else{
                isAlive = false
                waitThenResetTheGame()
            }
            
            if colorSelection == 2 && firstBodyTemp.name == "fallingBlock2"{
                secondBodyTemp.removeFromParent()
                score = score + 1
                updateScore()
            }
            else{
                isAlive = false
                waitThenResetTheGame()
            }
        }
    }
    
    func updateScore(){
        lblScore?.text = "Score: \(score)"
    }
    
    func waitThenResetTheGame(){
        let wait = SKAction.waitForDuration(5.0)
        let transition = SKAction.runBlock{
        let gameScene = GameScene(size: self.size)
            
        gameScene.scaleMode = SKSceneScaleMode.AspectFill
            
            self.view?.presentScene(gameScene, transition: SKTransition.crossFadeWithDuration(2.0))
            
        }
        
        let sequence = SKAction.sequence([wait, transition])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    
    //
    override func update(currentTime: CFTimeInterval) {
        if isAlive == false{
            lblMain?.text = "Game Over"
            player?.position.x = -300
        }
    }
}
