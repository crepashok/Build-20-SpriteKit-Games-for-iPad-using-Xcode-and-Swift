//
//  GameScene.swift
//  Space Shooter for TVOS
//
//  Created by John Bura on 2016-01-13.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var player = SKSpriteNode?()
var enemy = SKSpriteNode?()
var projectile = SKSpriteNode?()
var star = SKSpriteNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()

var playerSize = CGSize(width: 50, height: 50)
var enemySize = CGSize(width: 40, height: 40)
var projectileSize = CGSize(width: 10, height: 10)
var starSize = CGSize?()

var offBlackColor = UIColor(red: (20/255), green: (30/255), blue: (20/255), alpha: 1.0)
var offWhiteColor = UIColor(red: (140/255), green: (170/255), blue: (125/255), alpha: 1.0)

var touchLocation = CGPoint?()

var enemySpeed : Double = 2.0
var enemySpawnRate : Double = 1.0
var projectileSpeed : Double = 1.0
var projectileSpawnRate : Double = 0.1

var isAlive = true

var score = 0

struct physicsCategory {
    static let player : UInt32 = 1
    static let projectile : UInt32 = 2
    static let enemy : UInt32 = 3
}

//
class GameScene: SKScene, SKPhysicsContactDelegate {
    override func didMoveToView(view: SKView) {
        self.backgroundColor = offBlackColor
        physicsWorld.contactDelegate = self
        
        resetVariablesOnStart()
        
        spawnPlayer()
        timerEnemySpawn()
        timerStarSpawn()
        timerSpawnProjectile()
        
        spawnLblMain()
        spawnLblScore()
        
        timerSetLblAlpha()
    }
    
    func resetVariablesOnStart(){
        isAlive = true
        
        score = 0
        
        lblMain?.alpha = 1.0
        lblMain?.text = "Start"
        
        lblScore?.alpha = 1.0
        lblScore?.text = "Score: \(score)"
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches {
            touchLocation = touch.locationInNode(self)

        }
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches{
            touchLocation = touch.locationInNode(self)
            
            if isAlive == true{
                player?.position.y = (touchLocation?.y)!
            }
        
        }
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontSize = 150
        lblMain?.fontColor = offWhiteColor
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 50)
        
        lblMain!.text = "Start!"
        
        self.addChild(lblMain!)
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontSize = 40
        lblScore?.fontColor = offWhiteColor
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMinY(self.frame) + 130)
        
        lblScore?.text = "Score: \(score)"
        
        self.addChild(lblScore!)
    }
    
    func spawnPlayer(){
        player = SKSpriteNode(color: offWhiteColor, size: playerSize)
        player?.position = CGPoint(x: CGRectGetMinX(self.frame) + 100, y: CGRectGetMidY(self.frame))
        player?.name = "playerName"
        
        player?.physicsBody = SKPhysicsBody(rectangleOfSize: (player?.size)!)
        player?.physicsBody?.affectedByGravity = false
        player?.physicsBody?.allowsRotation = false
        player?.physicsBody?.categoryBitMask = physicsCategory.player
        player?.physicsBody?.contactTestBitMask = physicsCategory.enemy
        player?.physicsBody?.dynamic = true
        
        self.addChild(player!)
    }
    
    func spawnEnemy(){
        var randomY = Int(arc4random_uniform(500) + 140)
        
        enemy = SKSpriteNode(color: offWhiteColor, size: enemySize)
        enemy?.position = CGPoint(x: 1200, y: randomY)
        enemy?.name = "enemyName"
        
        enemy?.physicsBody = SKPhysicsBody(rectangleOfSize: (enemy?.size)!)
        enemy?.physicsBody?.affectedByGravity = false
        enemy?.physicsBody?.allowsRotation = false
        enemy?.physicsBody?.categoryBitMask = physicsCategory.enemy
        enemy?.physicsBody?.contactTestBitMask = physicsCategory.player
        enemy?.physicsBody?.dynamic = true
        
        moveEnemyForward()
        self.addChild(enemy!)
    }
    
    func moveEnemyForward(){
        let moveFoward = SKAction.moveToX(-100, duration: enemySpeed)
        let destroy = SKAction.removeFromParent()
        
        enemy?.runAction(SKAction.sequence([moveFoward, destroy]))
        
    }
    
    func timerEnemySpawn(){
        let wait = SKAction.waitForDuration(enemySpawnRate)
        let spawn = SKAction.runBlock{
            if isAlive == true{
                self.spawnEnemy()
            }
        }
        let sequence = SKAction.sequence([wait, spawn])
        self.runAction(SKAction.repeatActionForever(sequence))
    }
    
    func spawnStar(){
        let randomWidth = Int(arc4random_uniform(3) + 1)
        let randomHeight = Int(arc4random_uniform(3) + 1)
        
        var randomY = Int(arc4random_uniform(500) + 125)
        
        starSize = CGSize(width: randomWidth, height: randomHeight)
        
        star = SKSpriteNode(color: offWhiteColor, size: starSize!)
        star?.position = CGPoint(x: 1200, y: randomY)
        star?.zPosition = -1
        
        
        starMoveFoward()
        self.addChild(star!)
    }
    
    func starMoveFoward(){
        
        let randomSpeed = Int(arc4random_uniform(3) + 1)
        
        let moveFoward = SKAction.moveToX(-100, duration: Double(randomSpeed))
        let destroy = SKAction.removeFromParent()
        
        star?.runAction(SKAction.sequence([moveFoward, destroy]))
        
    }
    
    func timerStarSpawn(){
        let wait = SKAction.waitForDuration(0.1)
        let spawn = SKAction.runBlock{

                self.spawnStar()
           
        }
        let sequence = SKAction.sequence([wait, spawn])
        self.runAction(SKAction.repeatActionForever(sequence))
    }
    
    func spawnProjectile(){
        projectile = SKSpriteNode(color: offWhiteColor, size: projectileSize)
        projectile?.position.y = (player?.position.y)!
        projectile?.position.x = (player?.position.x)! + 50
        projectile?.name = "projectileName"
        
        projectile?.physicsBody = SKPhysicsBody(rectangleOfSize: (projectile?.size)!)
        projectile?.physicsBody?.affectedByGravity = false
        projectile?.physicsBody?.allowsRotation = false
        projectile?.physicsBody?.categoryBitMask = physicsCategory.projectile
        projectile?.physicsBody?.contactTestBitMask = physicsCategory.enemy
        projectile?.physicsBody?.dynamic = true
        
        moveProjectileForward()
        self.addChild(projectile!)
    }
    
    func moveProjectileForward(){
        
        let moveFoward = SKAction.moveToX(1200, duration: projectileSpeed)
        let destroy = SKAction.removeFromParent()
        
        projectile?.runAction(SKAction.sequence([moveFoward, destroy]))
    }
    
    func timerSpawnProjectile(){
        let wait = SKAction.waitForDuration(projectileSpawnRate)
        let spawn = SKAction.runBlock{
            if isAlive == true{
                self.spawnProjectile()
            }
        }
        let sequence = SKAction.sequence([wait, spawn])
        self.runAction(SKAction.repeatActionForever(sequence))
    }
   
    func keepPlayerOnScreen(){
        if player?.position.y >= 640{
            player?.position.y = 640
        }
        
        if player?.position.y <= 125{
            player?.position.y = 125
        }
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
        let firstBody = contact.bodyA
        let secondBody = contact.bodyB
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.enemy) ||
            (firstBody.categoryBitMask == physicsCategory.enemy) && (secondBody.categoryBitMask == physicsCategory.player)){
            playerEnemyCollision(firstBody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
        
        if ((firstBody.categoryBitMask == physicsCategory.projectile) && (secondBody.categoryBitMask == physicsCategory.enemy) ||
            (firstBody.categoryBitMask == physicsCategory.enemy) && (secondBody.categoryBitMask == physicsCategory.projectile)){
                
                projectileEnemyCollision(firstBody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
        
        
    }
    
    func playerEnemyCollision(contactA: SKSpriteNode, contactB: SKSpriteNode){
        if contactA.name == "enemyName"{
            contactA.removeFromParent()
            isAlive = false
            gameOverLogic()
        }
        if contactB.name == "enemyName"{
            contactB.removeFromParent()
            isAlive = false
            gameOverLogic()
        }
        
        
    }
    
    func projectileEnemyCollision(contactA: SKSpriteNode, contactB: SKSpriteNode){
        if contactA.name == "enemyName"{
            score = score + 1
            updateScore()
            contactA.removeFromParent()
        }
        
        if contactB.name == "enemyName"{
            score = score + 1
            updateScore()
            contactB.removeFromParent()
        }
    }
    
    func updateScore(){
        lblScore?.text = "Score: \(score)"
    }
    
    func gameOverLogic(){
        lblMain?.alpha = 1.0
        lblMain?.text = "Game Over"
        
        lblScore?.alpha = 1.0
        
        resetTheGame()
    }
    
    func resetTheGame(){
        let wait = SKAction.waitForDuration(1.0)
        let theGameScene = GameScene(size: self.size)
        theGameScene.scaleMode = SKSceneScaleMode.AspectFill
        
        let theTransition = SKTransition.crossFadeWithDuration(0.4)
        
        let changeScene = SKAction.runBlock{
            self.scene?.view?.presentScene(theGameScene, transition: theTransition)
        }
        
        let sequence = SKAction.sequence([wait, changeScene])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    
    
    
    func movePlayerOffScreen(){
        if isAlive == false{
            player?.position.y = -300
        }
    }
    
    func timerSetLblAlpha(){
        let wait = SKAction.waitForDuration(3.0)
        let changeAlpha = SKAction.runBlock{
            lblMain?.alpha = 0.0
            lblScore?.alpha = 0.3
        }
        
        let sequence = SKAction.sequence([wait, changeAlpha])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    
    //
    override func update(currentTime: CFTimeInterval) {
        keepPlayerOnScreen()
        movePlayerOffScreen()
    }
}
