//
//  GameScene.swift
//  Move Blocks To Goal for iPad
//
//  Created by John Bura on 2016-01-13.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var player = SKSpriteNode?()
var collectables = SKSpriteNode?()
var topBlock = SKSpriteNode?()
var bottomBlock = SKSpriteNode?()

var lblMain = SKLabelNode?()

var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var orangeColorCustom = UIColor.orangeColor()

var playerSize = CGSize(width: 70, height: 40)
var collectableSize = CGSize(width: 10, height: 10)
var blockSize = CGSize(width: 300, height: 50)

var touchLocation = CGPoint?()

var score = 0

var collectablesCount = 0

struct physicsCategory {
    static let collectable : UInt32 = 1
    static let topBlock : UInt32 = 2
    static let bottomBlock : UInt32 = 3
}
//
class GameScene: SKScene, SKPhysicsContactDelegate {
    override func didMoveToView(view: SKView) {
        self.backgroundColor = orangeColorCustom
        physicsWorld.contactDelegate = self
        
        resetVariablesOnStart()

        spawnLblMain()

    }
    
    func resetVariablesOnStart(){
        score = 0
        collectablesCount = 0
        
        spawnBottomBlock()
        spawnPlayer()
        spawnTopBlock()
        
        spawnMultipleCollectables()
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
       
        
        for touch in touches {
            touchLocation = touch.locationInNode(self)
            
      
        }
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches{
            touchLocation = touch.locationInNode(self)
            
            player?.position.x = (touchLocation?.x)!
            player?.position.y = (touchLocation?.y)!
        }
    }
    
    func spawnMultipleCollectables(){
        for _ in 1...30{
            spawnCollectables()
            collectablesCount = collectablesCount + 1
          
        }
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 50)
        lblMain?.fontColor = offBlackColor
        lblMain?.fontSize = 55
        lblMain?.text = "Move Blocks To Goal"
        lblMain?.zPosition = 1
        
        self.addChild(lblMain!)
        
    }
    //
    func spawnPlayer(){
        player = SKSpriteNode(color: offWhiteColor, size: playerSize)
        player?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame))
        player?.physicsBody = SKPhysicsBody(rectangleOfSize: (player?.size)!)
        player?.physicsBody?.affectedByGravity = false
        player?.physicsBody?.allowsRotation = false
        player?.physicsBody?.dynamic = true
        player?.name = "playerName"
        
        self.addChild(player!)
        
        
    }
    
    func spawnCollectables(){
        let randomX = Int(arc4random_uniform(500) + 300)
        let randomY = Int(arc4random_uniform(500) + 100)
        
        collectables = SKSpriteNode(color: offWhiteColor, size: collectableSize)
        collectables?.position = CGPoint(x: randomX, y: randomY)
        
        collectables?.physicsBody = SKPhysicsBody(rectangleOfSize: (collectables?.size)!)
        collectables?.physicsBody?.affectedByGravity = false
        collectables?.physicsBody?.allowsRotation = false
        collectables?.physicsBody?.dynamic = true
        collectables?.physicsBody?.categoryBitMask = physicsCategory.collectable
        collectables?.physicsBody?.contactTestBitMask = physicsCategory.topBlock
        
        collectables?.name = "collectablesName"
        
        self.addChild(collectables!)
        
    }
    
    func spawnTopBlock(){
        topBlock = SKSpriteNode(color: offBlackColor, size: blockSize)
        topBlock?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMaxY(self.frame) - 25)
        topBlock?.physicsBody = SKPhysicsBody(rectangleOfSize: (topBlock?.size)!)
        topBlock?.physicsBody?.affectedByGravity = false
        topBlock?.physicsBody?.allowsRotation = false
        topBlock?.physicsBody?.dynamic = false
        topBlock?.physicsBody?.categoryBitMask = physicsCategory.topBlock
        topBlock?.physicsBody?.contactTestBitMask = physicsCategory.collectable
        
        topBlock?.name = "topBlockName"
        
        self.addChild(topBlock!)
        
        
    }
    
    func spawnBottomBlock(){
        bottomBlock = SKSpriteNode(color: offBlackColor, size: blockSize)
        bottomBlock?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMinY(self.frame) + 25)
        bottomBlock?.physicsBody = SKPhysicsBody(rectangleOfSize: (bottomBlock?.size)!)
        bottomBlock?.physicsBody?.affectedByGravity = false
        bottomBlock?.physicsBody?.allowsRotation = false
        bottomBlock?.physicsBody?.dynamic = false
        bottomBlock?.physicsBody?.categoryBitMask = physicsCategory.bottomBlock
        bottomBlock?.physicsBody?.contactTestBitMask = physicsCategory.collectable
        
        bottomBlock?.name = "bottomBlockName"
        
        self.addChild(bottomBlock!)
        
        
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
        let firstbody = contact.bodyA
        let secondBody = contact.bodyB
        
        if ((firstbody.categoryBitMask == physicsCategory.collectable) && (secondBody.categoryBitMask == physicsCategory.topBlock) || (firstbody.categoryBitMask == physicsCategory.topBlock) && (secondBody.categoryBitMask == physicsCategory.collectable)){
            
            collectableTopBlockLogic(firstbody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
        
        if ((firstbody.categoryBitMask == physicsCategory.collectable) && (secondBody.categoryBitMask == physicsCategory.bottomBlock) || (firstbody.categoryBitMask == physicsCategory.bottomBlock) && (secondBody.categoryBitMask == physicsCategory.collectable)){
            
            collectableBottomBlockLogic(firstbody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
        
    }
    
    func collectableTopBlockLogic(contactA: SKSpriteNode, contactB: SKSpriteNode){
        if contactA.name == "collectablesName"{
            score = score + 1
            contactA.removeFromParent()
            collectablesCount = collectablesCount - 1
            updateScore()
        }
        
        if contactB.name == "collectablesName"{
                score = score + 1
            contactB.removeFromParent()
            collectablesCount = collectablesCount - 1
            updateScore()
        }
    }
    
    func collectableBottomBlockLogic(contactA: SKSpriteNode, contactB: SKSpriteNode){
        if contactA.name == "collectablesName"{
            score = score + 1
            contactA.removeFromParent()
            collectablesCount = collectablesCount - 1
            updateScore()
        }
        
        if contactB.name == "collectablesName"{
            score = score + 1
            contactB.removeFromParent()
            collectablesCount = collectablesCount - 1
            updateScore()
        }
    }
    
    func updateScore(){
        lblMain?.fontSize = 200
        lblMain?.text = "\(score)"
    }
    
    func gameOverLogic(){
        lblMain?.fontSize = 90
        lblMain?.text = "Congratulations!"
        
        player?.removeFromParent()
        topBlock?.removeFromParent()
        bottomBlock?.removeFromParent()
        
        resetTheGame()
    }
    
    func resetTheGame(){
        let wait = SKAction.waitForDuration(3.0)
        let theGameScene = GameScene(size: self.size)
        theGameScene.scaleMode = SKSceneScaleMode.AspectFill
        let theTransition = SKTransition.crossFadeWithDuration(1.0)
        
        let changeScene = SKAction.runBlock{
            self.scene?.view?.presentScene(theGameScene, transition: theTransition)
        }
        
        let sequence = SKAction.sequence([wait, changeScene])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
        
    }
    
   //
    override func update(currentTime: CFTimeInterval) {
        if collectablesCount <= 0{
            gameOverLogic()
        }
    }
}
