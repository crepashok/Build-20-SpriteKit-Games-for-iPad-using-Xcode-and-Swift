//
//  GameScene.swift
//  Gravity flip iPad
//
//  Created by John Bura on 2016-01-13.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var player = SKSpriteNode?()
var floor = SKSpriteNode?()
var ceiling = SKSpriteNode?()
var floorBlock = SKSpriteNode?()
var ceilingBlock = SKSpriteNode?()

var lblMain = SKLabelNode?()

var gravityDown = true
var touchGravity = true
var isAlive = true

var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var orangeColorCustom = UIColor.orangeColor()

var playerSize = CGSize(width: 50, height: 50)
var floorBlockSize = CGSize(width: 100, height: 100)

var floorHeight : CGFloat = 100.0

var downGravity = CGVector(dx: 0, dy: -100)
var upGravity = CGVector(dx: 0, dy: 100)

var blockSpeed : Double = 2.0

struct physicsCategory {
    static let player : UInt32 = 1
    static let floorBlock : UInt32 = 2
    static let ceilingBlock : UInt32 = 3
}

//
class GameScene: SKScene, SKPhysicsContactDelegate {
    override func didMoveToView(view: SKView) {
        physicsWorld.contactDelegate = self
        self.backgroundColor = orangeColorCustom
        
        self.physicsWorld.gravity = downGravity
        resetVariablesOnStart()
        
        spawnCeiling()
        spawnFloor()
        spawnPlayer()
        
        spawnLblMain()
        
        timerSpawnCeilingBlock()
        timerSpawnFloorBlock()
       
    }
    
    func resetVariablesOnStart(){
        gravityDown = true
        touchGravity = true
        isAlive = true
        
        lblMain?.text = "Tap! Tap! Tap!"
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {

        for touch in touches {
            let location = touch.locationInNode(self)
            
            gravitySwitchLogic()
        }
    }
    
    func gravitySwitchLogic(){
        if gravityDown == true && touchGravity == true{
            self.physicsWorld.gravity = upGravity
            gravityDown = false
        }
        if gravityDown == false && touchGravity == false{
            self.physicsWorld.gravity = downGravity
            gravityDown = true
            touchGravity = true
        }
        if gravityDown == false && touchGravity == true{
            touchGravity = false
        }
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontSize = 130
        lblMain?.fontColor = offWhiteColor
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 150)
        lblMain?.text = "Tap! Tap! Tap!"
        
        self.addChild(lblMain!)
    }
    
    func spawnFloor(){
        floor = SKSpriteNode(color: offBlackColor, size: CGSize(width: self.frame.width, height: floorHeight))
        floor?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMinY(self.frame))
        
        floor?.physicsBody = SKPhysicsBody(rectangleOfSize: (floor?.size)!)
        floor?.physicsBody?.affectedByGravity = false
        floor?.physicsBody?.allowsRotation = false
        floor?.physicsBody?.dynamic = false
        
        self.addChild(floor!)
 
    }
    
    func spawnCeiling(){
        ceiling = SKSpriteNode(color: offBlackColor, size: CGSize(width: self.frame.width, height: floorHeight))
        ceiling?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMaxY(self.frame))
        
        ceiling?.physicsBody = SKPhysicsBody(rectangleOfSize: (ceiling?.size)!)
        ceiling?.physicsBody?.affectedByGravity = false
        ceiling?.physicsBody?.allowsRotation = false
        ceiling?.physicsBody?.dynamic = false
        
        self.addChild(ceiling!)
    }
    
    func spawnPlayer(){
        player = SKSpriteNode(color: offWhiteColor, size: playerSize)
        player?.position = CGPoint(x: 150, y: 150)
        
        player?.physicsBody = SKPhysicsBody(rectangleOfSize: (player?.size)!)
        player?.physicsBody?.affectedByGravity = true
        player?.physicsBody?.allowsRotation = false
        player?.physicsBody?.dynamic = true
        player?.physicsBody?.categoryBitMask = physicsCategory.player
        player?.physicsBody?.contactTestBitMask = physicsCategory.floorBlock
        
        player?.name = "playerName"
        
        self.addChild(player!)
    }
    
    func spawnFloorBlock(){
        floorBlock = SKSpriteNode(color: offBlackColor, size: floorBlockSize)
        floorBlock?.position = CGPoint(x: CGRectGetMaxX(self.frame) + 150, y: CGRectGetMinY(self.frame) + 100)
        floorBlock?.physicsBody = SKPhysicsBody(rectangleOfSize: (floorBlock?.size)!)
        floorBlock?.physicsBody?.affectedByGravity = false
        floorBlock?.physicsBody?.allowsRotation = false
        floorBlock?.physicsBody?.dynamic = true
        floorBlock?.physicsBody?.categoryBitMask = physicsCategory.floorBlock
        floorBlock?.physicsBody?.contactTestBitMask = physicsCategory.player
        
        floorBlock?.name = "floorBlockName"
        
        moveFloorBlock()
        
        self.addChild(floorBlock!)
        
    }
    
    func spawnCeilingBlock(){
        ceilingBlock = SKSpriteNode(color: offBlackColor, size: floorBlockSize)
        ceilingBlock?.position = CGPoint(x: CGRectGetMaxX(self.frame) + 150, y: CGRectGetMaxY(self.frame) - 100)
        ceilingBlock?.physicsBody = SKPhysicsBody(rectangleOfSize: (ceilingBlock?.size)!)
        ceilingBlock?.physicsBody?.affectedByGravity = false
        ceilingBlock?.physicsBody?.allowsRotation = false
        ceilingBlock?.physicsBody?.dynamic = true
        ceilingBlock?.physicsBody?.categoryBitMask = physicsCategory.ceilingBlock
        ceilingBlock?.physicsBody?.contactTestBitMask = physicsCategory.player
        
        ceilingBlock?.name = "ceilingBlockName"
        
        moveCeilingBlock()
        
        self.addChild(ceilingBlock!)
        
    }
    
    func moveFloorBlock(){
        let moveBlock = SKAction.moveToX(-200, duration: blockSpeed)
        let destroy = SKAction.removeFromParent()
        
        let sequence = SKAction.sequence([moveBlock, destroy])
        floorBlock?.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    func moveCeilingBlock(){
        let moveBlock = SKAction.moveToX(-200, duration: blockSpeed)
        let destroy = SKAction.removeFromParent()
        
        let sequence = SKAction.sequence([moveBlock, destroy])
        ceilingBlock?.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    
    func timerSpawnFloorBlock(){
        let randomTime = Int(arc4random_uniform(5) + 3)
        
        let wait = SKAction.waitForDuration(Double(randomTime))
        let spawnBlock = SKAction.runBlock{
            if isAlive == true{
                self.spawnFloorBlock()
            }
        }
        
        let sequence = SKAction.sequence([wait, spawnBlock])
        self.runAction(SKAction.repeatActionForever(sequence))
        
    }
    
    func timerSpawnCeilingBlock(){
        let randomTime = Int(arc4random_uniform(2) + 2)
        
        let wait = SKAction.waitForDuration(Double(randomTime))
        let spawnBlock = SKAction.runBlock{
            if isAlive == true{
                self.spawnCeilingBlock()
            }
        }
        
        let sequence = SKAction.sequence([wait, spawnBlock])
        self.runAction(SKAction.repeatActionForever(sequence))
        
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
        var firstBody = contact.bodyA
        var secondBody = contact.bodyB
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.floorBlock) || (firstBody.categoryBitMask == physicsCategory.floorBlock) && (secondBody.categoryBitMask == physicsCategory.player)){
            
            floorBlockCollisionLogic(firstBody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.ceilingBlock) || (firstBody.categoryBitMask == physicsCategory.ceilingBlock) && (secondBody.categoryBitMask == physicsCategory.player)){
            
            ceilingBlockCollisionLogic(firstBody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
        
    }
    
    func floorBlockCollisionLogic(contactA: SKSpriteNode, contactB: SKSpriteNode){
        if contactA.name == "playerName"{
            gameOverLogic()
        }
        if contactB.name == "playerName"{
            gameOverLogic()
        }
    }
    
    func ceilingBlockCollisionLogic(contactA: SKSpriteNode, contactB: SKSpriteNode){
        if contactA.name == "playerName"{
            gameOverLogic()
        }
        if contactB.name == "playerName"{
            gameOverLogic()
        }
    }
    
    func gameOverLogic(){
        isAlive = false
        
        player?.removeFromParent()
        floorBlock?.removeFromParent()
        ceilingBlock?.removeFromParent()
        
        lblMain?.text = "Game Over"
        
        resetTheGame()
    }
    
    func resetTheGame(){
        let wait = SKAction.waitForDuration(3.0)
        let theGameScene = GameScene(size: self.size)
        theGameScene.scaleMode = SKSceneScaleMode.AspectFill
        let theTransition = SKTransition.doorsCloseVerticalWithDuration(0.5)
        let changeScene = SKAction.runBlock{
            self.scene?.view?.presentScene(theGameScene, transition: theTransition)
        }
        
        let sequence = SKAction.sequence([wait, changeScene])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
   
    //
    override func update(currentTime: CFTimeInterval) {
       
    }
}
