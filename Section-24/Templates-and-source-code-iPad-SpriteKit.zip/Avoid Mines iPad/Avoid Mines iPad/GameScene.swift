//
//  GameScene.swift
//  Avoid Mines iPad
//
//  Created by John Bura on 2016-01-11.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var player = SKSpriteNode?()
var mine = SKSpriteNode?()
var goal = SKSpriteNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()

var touchedNode = SKNode?()

var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var greenColorCustom = UIColor(red: (0/255), green: (128/255), blue: (64/255), alpha: 1.0)

var playerSize = CGSize(width: 50, height: 50)
var goalSize = CGSize(width: 40, height: 40)
var mineSize = CGSize(width: 20, height: 20)

var goalPosition0 = CGPoint(x: 300, y: 50)
var goalPosition1 = CGPoint(x: 750, y: 700)

var touchLocation = CGPoint?()

var mineQuantity = 3

var goalLocation = 0
var hasReachedGoal = false

var score = 0

struct physicsCategory {
    static let player : UInt32 = 1
    static let mine : UInt32 = 2
    static let goal : UInt32 = 3
}

//
class GameScene: SKScene, SKPhysicsContactDelegate {
    override func didMoveToView(view: SKView) {
            self.backgroundColor = greenColorCustom
        
        physicsWorld.contactDelegate = self
        
        resetVariablesOnStart()
        
        spawnLblMain()
        spawnLblScore()
        
        randomlyGenerateMines()
        
    }
    
    func resetVariablesOnStart(){
        spawnPlayer()
        spawnGoal()
        
        mineQuantity = 3
        
        goalLocation = 0
        hasReachedGoal = false
        
        score = 0
        
        lblMain?.alpha = 0.5
        lblMain?.fontSize = 50
        lblMain?.text = "Game Over"
        
        lblScore?.fontSize = 40
        lblScore?.alpha = 0.5
        
        updateScore()
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        
        for touch in touches{
            touchLocation = touch.locationInNode(self)
            gameOverLogic()
        }
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches {
            touchLocation = touch.locationInNode(self)
            
            movePlayer()
        }
    }
    
    func movePlayer(){
        touchedNode = nodeAtPoint(touchLocation!)
        
        player?.position.x = (touchLocation?.x)!
        player?.position.y = (touchLocation?.y)!
    }
    
    
    func spawnPlayer(){
        player = SKSpriteNode(color: offWhiteColor, size: playerSize)
        player?.position = goalPosition1
        
        player?.physicsBody = SKPhysicsBody(rectangleOfSize: (player?.size)!)
        player?.physicsBody?.affectedByGravity = false
        player?.physicsBody?.categoryBitMask = physicsCategory.player
        player?.physicsBody?.contactTestBitMask = physicsCategory.goal
        player?.physicsBody?.dynamic = false
        player?.physicsBody?.allowsRotation = false
        
        player?.name = "playerName"
        
        self.addChild(player!)
    }
    
    func randomlyGenerateMines(){
        for _ in 1...mineQuantity{
            spawnMine()
        }
    }
    
    func spawnMine(){
        let randomX = Int(arc4random_uniform(500) + 300)
        let randomY = Int(arc4random_uniform(580) + 100)
        
        mine = SKSpriteNode(color: offBlackColor, size: mineSize)
        mine?.position = CGPoint(x: randomX, y: randomY)
        
        mine?.physicsBody = SKPhysicsBody(rectangleOfSize: (mine?.size)!)
        mine?.physicsBody?.affectedByGravity = false
        mine?.physicsBody?.categoryBitMask = physicsCategory.mine
        mine?.physicsBody?.contactTestBitMask = physicsCategory.player
        mine?.physicsBody?.dynamic = true
        
        mine?.name = "mineName"
        
        self.addChild(mine!)
    }
    
    func spawnGoal(){
        goal = SKSpriteNode(color: offWhiteColor, size: goalSize)
        goal?.position = goalPosition1
        
        goal?.physicsBody = SKPhysicsBody(rectangleOfSize: (goal?.size)!)
        goal?.physicsBody?.affectedByGravity = false
        goal?.physicsBody?.categoryBitMask = physicsCategory.goal
        goal?.physicsBody?.contactTestBitMask = physicsCategory.player
        goal?.physicsBody?.allowsRotation = false
        goal?.physicsBody?.dynamic = true
        
        goal?.name = "GoalName"
        
        self.addChild(goal!)
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontColor = offWhiteColor
        lblMain?.fontSize = 50
        lblMain?.alpha = 0.5
        lblMain?.zPosition = -1
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 170)
        
        lblMain?.text = "Drag and Avoid Mines"
        
        self.addChild(lblMain!)
        
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontColor = offWhiteColor
        lblScore?.fontSize = 40
        lblScore?.alpha = 0.5
        lblScore?.zPosition = -1
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 350)
        
        lblScore?.text = "Score: \(score)"
        
        self.addChild(lblScore!)
        
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
        var firstBody = contact.bodyA
        var secondBody = contact.bodyB
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.mine) || (firstBody.categoryBitMask == physicsCategory.mine) && (secondBody.categoryBitMask == physicsCategory.player)){
                playerMineContact(firstBody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.goal) || (firstBody.categoryBitMask == physicsCategory.goal) && (secondBody.categoryBitMask == physicsCategory.player)){
           
            playerGoalContact(firstBody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
    }
    
    func playerMineContact(contactA: SKSpriteNode, contactB: SKSpriteNode){
        gameOverLogic()
    }
    
    func playerGoalContact(contactA: SKSpriteNode, contactB: SKSpriteNode){
        hasReachedGoal = true
        
        if goalLocation == 0 && hasReachedGoal == true{
            goalLocation = 1
            hasReachedGoal = false
        }
        
        if goalLocation == 1 && hasReachedGoal == true{
            goalLocation = 0
            hasReachedGoal = false
        }
        
        mineQuantity = mineQuantity + 1
        
        score = score + 1
        updateScore()
        destroyAllMines()
        randomlyGenerateMines()
        
    }
    
    func updateScore(){
        lblScore?.text = "Score: \(score)"
    }
    
    func goalPositionLogic(){
        if goalLocation == 0{
            goal?.position = goalPosition0
        }
        
        if goalLocation == 1{
            goal?.position = goalPosition1
        }
        


    }
    
    func destroyAllMines(){
        self.enumerateChildNodesWithName("mineName", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.removeFromParent()
            }
        
        })
    }
    
    func gameOverLogic(){
        destroyAllMines()
        player?.removeFromParent()
        goal?.removeFromParent()
        
        lblMain?.alpha = 1.0
        lblMain?.fontSize = 90
        lblMain?.text = "Game Over"
        
        lblScore?.fontSize = 60
        lblScore?.alpha = 1.0
        
        resetTheGame()
    }
    
    func resetTheGame(){
        let wait = SKAction.waitForDuration(3.0)
        let theGameScene = GameScene(size: self.size)
        theGameScene.scaleMode = SKSceneScaleMode.AspectFill
        let theTransition = SKTransition.fadeWithColor(offWhiteColor, duration: 1.0)
        
        let changeScene = SKAction.runBlock{
            self.scene?.view?.presentScene(theGameScene, transition: theTransition)
        }
        
        let sequence = SKAction.sequence([wait, changeScene])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
   
    //
    override func update(currentTime: CFTimeInterval) {
        goalPositionLogic()
    }
}
