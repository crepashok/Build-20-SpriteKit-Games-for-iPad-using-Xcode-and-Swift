//
//  GameScene.swift
//  Follow the leader for iPad
//
//  Created by John Bura on 2016-01-12.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var leader = SKSpriteNode?()
var collectable = SKSpriteNode?()
var player = SKSpriteNode?()
var blockAvoid0 = SKSpriteNode?()
var blockAvoid1 = SKSpriteNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()

var leaderSize = CGSize(width: 70, height: 70)
var collectableSize = CGSize(width: 10, height: 10)
var playerSize = CGSize(width: 40, height: 40)
var blockAvoidSize = CGSize(width: 20, height: 20)

var leaderPosition = CGPoint?()

var offBlackColor = UIColor(red: 0.1, green: 0.1, blue: 0.1, alpha: 1.0)
var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var greenColorCustom = UIColor(red: 0, green: 0.5, blue: 0.2, alpha: 1.0)

var leaderCircleSpeed : Double = 30.0

var dropSpeed : Double = 2.0
var blockAvoidSpeed : Double = 1.5
var blockSpawnTime : Double = 0.9

var touchLocation = CGPoint?()

var isInTouch = true
var isGameOver = false

var score = 0

var blockSpawnAmount = 1

struct physicsCategory {
    static let player : UInt32 = 1
    static let blockAvoid0 : UInt32 = 2
    static let blockAvoid1 : UInt32 = 3
    static let leader : UInt32 = 4
    static let collectable : UInt32 = 5
}

//
class GameScene: SKScene, SKPhysicsContactDelegate {
    override func didMoveToView(view: SKView) {
       self.backgroundColor = greenColorCustom
        
        physicsWorld.contactDelegate = self
        resetGameVariablesOnStart()
        
        spawnLeader()
        spawnPlayer()
        
        timerSpawnCollectable()
        timerSpawnAvoidBlocks()
        
        spawnLblMain()
        spawnLblScore()
        
        
        
    }
    
    func resetGameVariablesOnStart(){
        isInTouch = true
        isGameOver = false
        
        score = 0
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontColor = offWhiteColor
        lblMain?.fontSize = 70
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 270)
        lblMain?.text = "Collect Leftovers"
        
        self.addChild(lblMain!)
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontColor = offWhiteColor
        lblScore?.fontSize = 40
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 350)
        lblScore?.text = "Score: \(score)"
        
        self.addChild(lblScore!)
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches{
            isInTouch = false
            gameOverLogic()
        }
    }
    
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches{
            touchLocation = touch.locationInNode(self)
            
            if isGameOver == false{
                player?.position.x = (touchLocation?.x)!
                player?.position.y = (touchLocation?.y)!
            }
        }
    }
    
    func spawnLeader(){
        leader = SKSpriteNode(color: offWhiteColor, size: leaderSize)
        leader?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame))
        calculateLeaderPosition()
        
        leader?.physicsBody = SKPhysicsBody(rectangleOfSize: (leader?.size)!)
        leader?.physicsBody?.affectedByGravity = false
        leader?.physicsBody?.categoryBitMask = physicsCategory.leader
        leader?.physicsBody?.contactTestBitMask = physicsCategory.player
        leader?.physicsBody?.allowsRotation = false
        leader?.physicsBody?.dynamic = true
        leader?.name = "leaderName"

        
        addLeaderCirclePath()
        
        self.addChild(leader!)
    }
    
    func addLeaderCirclePath(){
        let middleX : CGFloat = CGRectGetMidX(self.frame) - 180
        let middleY : CGFloat = CGRectGetMidY(self.frame) - 150
        
        let circlePath = UIBezierPath(roundedRect: CGRectMake(middleX, middleY, 350, 350), cornerRadius: 200)
        
        let followCirclePath = SKAction.followPath(circlePath.CGPath, asOffset: false, orientToPath: true, duration: leaderCircleSpeed)
        
        leader?.runAction(SKAction.repeatActionForever(followCirclePath))
    }
    
    func spawnCollectable(){
        collectable = SKSpriteNode(color: offWhiteColor, size: collectableSize)
        collectable?.position.x = (leader?.position.x)!
        collectable?.position.y = (leader?.position.y)!
        collectable?.zPosition = -1
        
        collectable?.physicsBody = SKPhysicsBody(rectangleOfSize: (collectable?.size)!)
        collectable?.physicsBody?.affectedByGravity = false
        collectable?.physicsBody?.categoryBitMask = physicsCategory.collectable
        collectable?.physicsBody?.contactTestBitMask = physicsCategory.player
        collectable?.physicsBody?.allowsRotation = false
        collectable?.physicsBody?.dynamic = true
        
        collectable?.name = "collectableName"
        
        self.addChild(collectable!)
    }
    
    func spawnPlayer(){
        player = SKSpriteNode(color: offWhiteColor, size: playerSize)
        player?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame))
        
        player?.physicsBody = SKPhysicsBody(rectangleOfSize: (player?.size)!)
        player?.physicsBody?.affectedByGravity = false
        player?.physicsBody?.categoryBitMask = physicsCategory.player
        player?.physicsBody?.contactTestBitMask = physicsCategory.collectable
        player?.physicsBody?.allowsRotation = false
        player?.physicsBody?.dynamic = true
        
        player?.name = "playerName"
        
        
        self.addChild(player!)
    }
    //
    func timerSpawnCollectable(){
        let wait = SKAction.waitForDuration(dropSpeed)
        let drop = SKAction.runBlock{
            if isGameOver == false{
                self.spawnCollectable()
            }
        }
        let sequence = SKAction.sequence([wait, drop])
        self.runAction(SKAction.repeatActionForever(sequence))
    }
    
    
    func calculateLeaderPosition(){
        leaderPosition?.x = (leader?.position.x)!
        leaderPosition?.y = (leader?.position.y)!
    }
    
    func spawnBlockAvoid0(){
        let randomY = Int(arc4random_uniform(600) + 50)
        
        blockAvoid0 = SKSpriteNode(color: offBlackColor, size: blockAvoidSize)
        blockAvoid0?.position = CGPoint(x: 200, y: randomY)
        
        blockAvoid0?.physicsBody = SKPhysicsBody(rectangleOfSize: (blockAvoid0?.size)!)
        blockAvoid0?.physicsBody?.affectedByGravity = false
        blockAvoid0?.physicsBody?.categoryBitMask = physicsCategory.blockAvoid0
        blockAvoid0?.physicsBody?.contactTestBitMask = physicsCategory.player
        blockAvoid0?.physicsBody?.allowsRotation = false
        blockAvoid0?.physicsBody?.dynamic = true
        
        blockAvoid0?.name = "blockAvoid0Name"
        
        moveBlockAvoid()
        
        self.addChild(blockAvoid0!)
        
    }
    
    func spawnBlockAvoid1(){
        let randomY = Int(arc4random_uniform(600) + 50)
        
        blockAvoid1 = SKSpriteNode(color: offBlackColor, size: blockAvoidSize)
        blockAvoid1?.position = CGPoint(x: 800, y: randomY)
        
        blockAvoid1?.physicsBody = SKPhysicsBody(rectangleOfSize: (blockAvoid1?.size)!)
        blockAvoid1?.physicsBody?.affectedByGravity = false
        blockAvoid1?.physicsBody?.categoryBitMask = physicsCategory.blockAvoid1
        blockAvoid1?.physicsBody?.contactTestBitMask = physicsCategory.player
        blockAvoid1?.physicsBody?.allowsRotation = false
        blockAvoid1?.physicsBody?.dynamic = true
        
        blockAvoid1?.name = "blockAvoid1Name"
        
        moveBlockAvoid()
        
        self.addChild(blockAvoid1!)
        
    }
    
    func moveBlockAvoid(){
        let moveRight = SKAction.moveToX(700, duration: blockAvoidSpeed)
        let moveLeft = SKAction.moveToX(0, duration: blockAvoidSpeed)
        let destroy = SKAction.removeFromParent()
        
        let sequence0 = SKAction.sequence([moveRight, destroy])
        let sequence1 = SKAction.sequence([moveLeft, destroy])
        
        blockAvoid0?.runAction(SKAction.repeatActionForever(sequence0))
        blockAvoid1?.runAction(SKAction.repeatActionForever(sequence1))
    }
    
    func timerSpawnAvoidBlocks(){
        let wait = SKAction.waitForDuration(blockSpawnTime)
        let drop = SKAction.runBlock{
            if isGameOver == false{
                for _ in 1...blockSpawnAmount{
                    self.spawnBlockAvoid0()
                    self.spawnBlockAvoid1()
                }
            }

        }
        
        let sequence = SKAction.sequence([wait, drop])
        self.runAction(SKAction.repeatActionForever(sequence))
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
        var firstBody = contact.bodyA
        var secondBody = contact.bodyB
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.leader) ||
            (firstBody.categoryBitMask == physicsCategory.leader) && (secondBody.categoryBitMask == physicsCategory.player)){
            
                playerLeaderCollision(firstBody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.collectable) ||
            (firstBody.categoryBitMask == physicsCategory.collectable) && (secondBody.categoryBitMask == physicsCategory.player)){
                
                playerCollectable(firstBody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
        
      
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.blockAvoid0) ||
            (firstBody.categoryBitMask == physicsCategory.collectable) && (secondBody.categoryBitMask == physicsCategory.blockAvoid0)){
                
                playerBlock0(firstBody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.blockAvoid1) ||
            (firstBody.categoryBitMask == physicsCategory.collectable) && (secondBody.categoryBitMask == physicsCategory.blockAvoid1)){
                
                playerBlock1(firstBody.node as! SKSpriteNode, contactB: secondBody.node as! SKSpriteNode)
        }

        
        
    }
    
    func playerLeaderCollision(contactA: SKSpriteNode, contactB: SKSpriteNode){
        gameOverLogic()
    }
    
    func playerCollectable(contactA: SKSpriteNode, contactB: SKSpriteNode){
        if contactA.name == "playerName"{
            score = score + 1
            updateScore()
        }
        
        if contactB.name == "playerName"{
            score = score + 1
            updateScore()
        }
        
        if contactA.name == "collectableName"{
            contactA.removeFromParent()
        }
        if contactB.name == "collectableName"{
            contactB.removeFromParent()
        }
    }
    
    func playerBlock0(contactA: SKSpriteNode, contactB: SKSpriteNode){
        gameOverLogic()
    }
    
    func playerBlock1(contactA: SKSpriteNode, contactB: SKSpriteNode){
        gameOverLogic()
    }
    
    func updateScore(){
        lblScore?.text = "Score: \(score)"
    }
    
    func gameOverLogic(){
        isGameOver = true
        
        self.enumerateChildNodesWithName("blockAvoid0Name", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.removeFromParent()
            }
        })
        
        self.enumerateChildNodesWithName("blockAvoid1Name", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.removeFromParent()
            }
        })
        
        self.enumerateChildNodesWithName("collectableName", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.removeFromParent()
            }
        })
        
        lblMain?.fontSize = 90
        lblMain?.text = "Game Over"
        
        resetTheGame()
    }
    
    func resetTheGame(){
        let wait = SKAction.waitForDuration(4.0)
        let theGameScene = GameScene(size: self.size)
        theGameScene.scaleMode = SKSceneScaleMode.AspectFill
        
        let theTransition = SKTransition.crossFadeWithDuration(1.0)
        let changeScene = SKAction.runBlock{
            self.scene!.view?.presentScene(theGameScene, transition: theTransition)
        }
        
        let sequence = SKAction.sequence([wait, changeScene])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
    }
    
    //
    override func update(currentTime: CFTimeInterval) {
        calculateLeaderPosition()
        
        if isGameOver == true{
            player?.position = CGPoint(x: -100, y: -100)
        }
    }
}
