//
//  GameScene.swift
//  Collect Avoid game
//
//  Created by John Bura on 2015-12-07.
//  Copyright (c) 2015 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var player = SKSpriteNode?()
var squareCollect = SKSpriteNode?()
var circleAvoid = SKSpriteNode?()
var stars = SKSpriteNode?()

var lblScore = SKLabelNode?()
var lblMain = SKLabelNode?()

var squareSpeed = 1.5
var circleSpeed = 2.0

var isAlive = true

var score = 0

var HUDColor = UIColor.whiteColor()

var colorBackground = UIColor(red: (20/255), green: (30/255), blue: (20/255), alpha: 1.0)
var colorPlayer = UIColor(red: (120/255), green: (200/255), blue: (100/255), alpha: 1.0)
var colorStar = UIColor(red: (170/255), green: (200/255), blue: (160/255), alpha: 1.0)

struct physicsCategory {
    static let player : UInt32 = 1
    static let squareCollect : UInt32 = 2
    static let circleAvoid : UInt32 = 3
}
//
class GameScene: SKScene, SKPhysicsContactDelegate {
    override func didMoveToView(view: SKView) {
        
        physicsWorld.contactDelegate = self
        
        self.backgroundColor = colorBackground

        spawnPlayer()
        spawnSquareCollect()
        spawnCircleAvoid()
        spawnStars()
        
        squareSpawnTimer()
        circleSpawnTimer()
        starsSpawnTimer()
        
        spawnLblScore()
        spawnLblMain()
        
        hideLblMain()
        
        resetVariablesOnStart()
        
    }
    
    func resetVariablesOnStart(){
        isAlive = true
        score = 0
    }


    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches{
            let location = touch.locationInNode(self)
            
            if isAlive == true{
                
                player?.position.x = location.x
                lblScore?.position.x = location.x
            }
            
            if isAlive == false{
                player?.position.x = -200
                lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: (lblScore?.position.y)!)
            }
        }
    }
    
    //
    override func update(currentTime: CFTimeInterval) {
        if isAlive == false{
            player?.position.x = -200
            lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: (lblScore?.position.y)!)
        }
    }
    
    func spawnPlayer(){
        player = SKSpriteNode(color: colorPlayer, size: CGSize(width: 50, height: 50))
        player?.position = CGPoint(x: CGRectGetMidX(self.frame), y: 130)
        
        player?.physicsBody = SKPhysicsBody(rectangleOfSize: player!.size)
        player?.physicsBody?.affectedByGravity = false
        player?.physicsBody?.categoryBitMask = physicsCategory.player
        player?.physicsBody?.contactTestBitMask = physicsCategory.squareCollect
        
        player?.physicsBody?.dynamic = false
        
        self.addChild(player!)
        
    }
    
    func spawnSquareCollect(){
        squareCollect = SKSpriteNode(color: colorPlayer, size: CGSize(width: 30, height: 30))
        squareCollect?.position = CGPoint(x: Int(arc4random_uniform(700) + 300), y: 800)
        
        var moveForard = SKAction.moveToY(-100, duration: squareSpeed)
        let destroy = SKAction.removeFromParent()
        
        squareCollect?.physicsBody = SKPhysicsBody(rectangleOfSize: squareCollect!.size)
        squareCollect?.physicsBody?.affectedByGravity = false
        squareCollect?.physicsBody?.categoryBitMask = physicsCategory.squareCollect
        squareCollect?.physicsBody?.dynamic = true
        squareCollect?.physicsBody?.allowsRotation = false
        
        squareCollect?.runAction(SKAction.sequence([moveForard, destroy]))
        
        self.addChild(squareCollect!)
    }
    
    func spawnCircleAvoid(){
        circleAvoid = SKSpriteNode(imageNamed: "circleAvoid")
        circleAvoid?.size = CGSize(width: 30, height: 30)
        
        circleAvoid?.position = CGPoint(x: Int(arc4random_uniform(700) + 300), y: 800)
        
        circleAvoid?.physicsBody = SKPhysicsBody(circleOfRadius: 15)
        circleAvoid?.physicsBody?.affectedByGravity = false
        circleAvoid?.physicsBody?.categoryBitMask = physicsCategory.circleAvoid
        circleAvoid?.physicsBody?.dynamic = true
        circleAvoid?.physicsBody?.allowsRotation = false
        
        
        var moveForward = SKAction.moveToY(-100, duration: circleSpeed)
        let destroy = SKAction.removeFromParent()
        
        circleAvoid?.runAction(SKAction.sequence([moveForward, destroy]))
        
        self.addChild(circleAvoid!)
    }
    //
    func spawnStars(){
        let randomSize = Int(arc4random_uniform(3) + 1)
        
        let randomSpeed : Double = Double(arc4random_uniform(2) + 1)
        
        stars = SKSpriteNode(color: colorStar, size: CGSize(width: randomSize, height: randomSize))
        stars?.position = CGPoint(x: Int(arc4random_uniform(700) + 300), y: 800)
        stars?.zPosition = -1
        
        let moveForward = SKAction.moveToY(-100, duration: randomSpeed)
        let destroy = SKAction.removeFromParent()
        
        stars?.runAction(SKAction.sequence([moveForward, destroy]))
        
        self.addChild(stars!)
    }
    
    func squareSpawnTimer(){
        
        let squareTimer = SKAction.waitForDuration(1.0)
        
        let spawn = SKAction.runBlock{
            self.spawnSquareCollect()
        }
        
        let sequence = SKAction.sequence([squareTimer, spawn])
        
        self.runAction(SKAction.repeatActionForever(sequence))
        
    }
    
    func circleSpawnTimer(){
  
        
        let circleTimer = SKAction.waitForDuration(0.5)
        let spawn = SKAction.runBlock{
            self.spawnCircleAvoid()
        }
        
        let sequence = SKAction.sequence([circleTimer, spawn])
        
        self.runAction(SKAction.repeatActionForever(sequence))
        
    }
    
    func starsSpawnTimer(){
        
        let starTimer = SKAction.waitForDuration(0.05)
        let spawn = SKAction.runBlock{
            self.spawnStars()
        }
        
        let sequence = SKAction.sequence([starTimer, spawn])
        
        self.runAction(SKAction.repeatActionForever(sequence))
        
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Courier")
        lblScore?.fontSize = 60
        lblScore?.fontColor = colorStar
        lblScore?.position = CGPoint(x: (player?.position.x)!, y: (player?.position.y)! - 80)
        
        lblScore?.text = "\(score)"
        
        self.addChild(lblScore!)
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Courier")
        lblMain?.fontSize = 150
        lblMain?.fontColor = colorStar
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame))
        
        lblMain?.text = "Start!"
        
        self.addChild(lblMain!)
    }
    
    func hideLblMain(){
        
        let wait = SKAction.waitForDuration(3.0)
        let setAlpha = SKAction.runBlock{
            lblMain!.alpha = 0
        }
        
        self.runAction(SKAction.sequence([wait, setAlpha]))
    }
    //
    func didBeginContact(contact: SKPhysicsContact) {
        let firstBody : SKPhysicsBody = contact.bodyA
        let secondBody : SKPhysicsBody = contact.bodyB
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.squareCollect) ||
            (firstBody.categoryBitMask == physicsCategory.squareCollect) && (secondBody.categoryBitMask == physicsCategory.player)){
                
                spawnExplosion(firstBody.node as! SKSpriteNode)
                playerSquareCollision(firstBody.node as! SKSpriteNode, squareTemp: secondBody.node as! SKSpriteNode)
                
        }
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.circleAvoid) ||
            (firstBody.categoryBitMask == physicsCategory.circleAvoid) && (secondBody.categoryBitMask == physicsCategory.player)){
                
                playerCircleCollsion(firstBody.node as! SKSpriteNode, circleTemp: secondBody.node as! SKSpriteNode)
                
        }
    }
    
    func playerSquareCollision(playerTemp: SKSpriteNode, squareTemp: SKSpriteNode){
        squareTemp.removeFromParent()
        
        score = score + 1
        
        updateScore()
    }
    
    func playerCircleCollsion(playerTemp: SKSpriteNode, circleTemp: SKSpriteNode){
        lblMain?.fontSize = 60
        lblMain?.alpha = 1.0
        lblMain?.text = "Game Over"
        
        isAlive = false
        
        waitThenMoveToTitleScene()
    }
    //
    
    func updateScore(){
        lblScore?.text = "\(score)"
    }
    
    func waitThenMoveToTitleScene(){
        let wait = SKAction.waitForDuration(1.0)
        let transition = SKAction.runBlock{
            
            if let scene = TitleScene(fileNamed: "TitleScene"){
                let skView = self.view! as SKView
                skView.ignoresSiblingOrder = true
                
                scene.scaleMode = .AspectFill
                
                skView.presentScene(scene)
            }//
            
        }
        
        let sequence = SKAction.sequence([wait, transition])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
        
        
    }
    
    func spawnExplosion(squareTemp: SKSpriteNode){
        let explosionEmmitterPath : NSString = NSBundle.mainBundle().pathForResource("particleExplosion", ofType: "sks")!
        
        let explosion = NSKeyedUnarchiver.unarchiveObjectWithFile(explosionEmmitterPath as String) as! SKEmitterNode
        
        explosion.position = CGPoint(x: squareTemp.position.x, y: squareTemp.position.y)
        explosion.zPosition = -1
        explosion.targetNode = self
        
        self.addChild(explosion)
        
        let explosionTimerRemove = SKAction.waitForDuration(1.0)
        let removeExplosion = SKAction.runBlock{
            explosion.removeFromParent()
        }
        
        self.runAction(SKAction.sequence([explosionTimerRemove, removeExplosion]))
    }
    
    
    
    
    
    
    
    
}
