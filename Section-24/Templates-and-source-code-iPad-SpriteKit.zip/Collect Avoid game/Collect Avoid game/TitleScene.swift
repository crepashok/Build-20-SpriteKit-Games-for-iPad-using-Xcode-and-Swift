//
//  TitleScene.swift
//  Collect Avoid game
//
//  Created by John Bura on 2015-12-08.
//  Copyright © 2015 Mammoth Interactive. All rights reserved.
//

import Foundation
import SpriteKit

class TitleScene : SKScene{
    
    var btnPlay : UIButton!
    var gameTitle = SKLabelNode?()
    
    var HUDTextColor = UIColor.whiteColor()
    
    var colorBackground = UIColor(red: (20/255), green: (30/255), blue: (20/255), alpha: 1.0)
    var colorTitle = UIColor(red: (120/255), green: (200/255), blue: (100/255), alpha: 1.0)
    var colorButton = UIColor(red: (170/255), green: (200/255), blue: (160/255), alpha: 1.0)
    
    
    override func didMoveToView(view: SKView) {
        self.backgroundColor = colorBackground
        
        setUpText()
    }
    
    func setUpText(){
        gameTitle = SKLabelNode(fontNamed: "Courier")
        gameTitle?.fontSize = 110
        gameTitle?.fontColor = colorTitle
        gameTitle?.position = CGPoint(x: CGRectGetMidX(self.frame), y: 400)
        
        gameTitle?.text = "AVOID DX"
        
        self.addChild(gameTitle!)
        
        btnPlay = UIButton(frame: CGRect(x: 100, y: 100, width: 500, height: 100))
        btnPlay.center = CGPoint(x: (view?.frame.size.width)! / 2, y: 1200)
        btnPlay.titleLabel?.font = UIFont(name: "Courier", size: 150)
        btnPlay.setTitle("Play", forState: UIControlState.Normal)
        btnPlay.setTitleColor(colorButton, forState: UIControlState.Normal)
        btnPlay.addTarget(self, action: Selector("playTheGame"), forControlEvents: UIControlEvents.TouchUpInside)
        
        self.view?.addSubview(btnPlay)
       
        
        
        
        
    }
    
    func playTheGame(){
        
        self.view?.presentScene(GameScene(), transition: SKTransition.fadeWithDuration(1.0))
        btnPlay.removeFromSuperview()
        gameTitle?.removeFromParent()
        
        if let scene = GameScene(fileNamed: "GameScene"){
            let skView = self.view! as SKView
            skView.ignoresSiblingOrder = true
            
            scene.scaleMode = .AspectFill
            
            skView.presentScene(scene)
        }
        
        
    }
    
}
