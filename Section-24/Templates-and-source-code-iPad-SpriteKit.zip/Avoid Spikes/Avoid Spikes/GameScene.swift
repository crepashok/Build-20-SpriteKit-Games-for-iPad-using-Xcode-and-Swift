//
//  GameScene.swift
//  Avoid Spikes
//
//  Created by John Bura on 2015-12-11.
//  Copyright (c) 2015 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var player = SKSpriteNode?()
var spike = SKSpriteNode?()
var ground = SKSpriteNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()

var spikeSpeed = 0.8

var isAlive = true

var score = 0

var spikeTimeSpawnNumber = 0.2


var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var offBlackColor = UIColor(red: 0.19, green: 0.19, blue: 0.19, alpha: 1.0)

struct physicsCategory {
    static let player : UInt32 = 1
    static let spike : UInt32 = 2
}


var touchLocation : CGPoint?

class GameScene: SKScene, SKPhysicsContactDelegate {
    override func didMoveToView(view: SKView) {
        
        physicsWorld.contactDelegate = self
        
        self.backgroundColor = UIColor.orangeColor()
 
        spawnPlayer()
        spawnGround()
        spawnLblMain()
        spawnLlbScore()
        spikeSpawnTimer()
        hideLabel()
        resetVariablesOnStart()
        addToScore()

        
    }
    //
    func resetVariablesOnStart(){
        score = 0
        isAlive = true
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        for touch in touches{
            touchLocation = touch.locationInNode(self)
            
            if isAlive == true{
                player?.position.x = (touchLocation?.x)!
            }
            
            if isAlive == false{
                player?.position.x = -200
            }
            
        }
        
    }
   //
    override func update(currentTime: CFTimeInterval) {
        if isAlive == false{
            player?.position.x = -200
        }
    }
    //
    func spawnPlayer(){
        player = SKSpriteNode(imageNamed: "player")
        player?.size = CGSize(width: 50, height: 50)
        
        player?.position = CGPoint(x: CGRectGetMidX(self.frame), y: 120)
        
        player?.physicsBody = SKPhysicsBody(rectangleOfSize: player!.size)
        player?.physicsBody?.affectedByGravity = false
        player?.physicsBody?.allowsRotation = false
        player?.physicsBody?.categoryBitMask = physicsCategory.player
        player?.physicsBody?.contactTestBitMask = physicsCategory.spike
        player?.physicsBody?.dynamic = false
        
        
        self.addChild(player!)
    }
    
    func spawnSpike(){
        spike = SKSpriteNode(imageNamed: "spike")
        spike?.size = CGSize(width: 10, height: 120)
        
        spike?.position.x = CGFloat(arc4random_uniform(700) + 250)
        spike?.position.y = 900
        
        spike?.physicsBody = SKPhysicsBody(rectangleOfSize: spike!.size)
        spike?.physicsBody?.affectedByGravity = false
        spike?.physicsBody?.allowsRotation = false
        spike?.physicsBody?.categoryBitMask = physicsCategory.spike
        spike?.physicsBody?.contactTestBitMask = physicsCategory.player
        spike?.physicsBody?.dynamic = true
        
        var moveDown = SKAction.moveToY(-200, duration: spikeSpeed)
        
        if isAlive == true{
            moveDown = SKAction.moveToY(-200, duration: spikeSpeed)
        }
        
        if isAlive == false{
            moveDown =  SKAction.moveToY(2000, duration: spikeSpeed)
        }
        
        spike?.runAction(moveDown)
        
        self.addChild(spike!)

        
    }
    
    func spawnGround(){
        ground = SKSpriteNode(color: offBlackColor, size: CGSize(width: CGRectGetWidth(self.frame), height: 200))
        
        ground?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMinY(self.frame))
        
        self.addChild(ground!)
        
        
        
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontSize = 100
        lblMain?.fontColor = offWhiteColor
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 150)
        lblMain?.text = "Start!"
        
        self.addChild(lblMain!)
    }
    
    //
    
    func spawnLlbScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontSize = 55
        lblScore?.fontColor = offWhiteColor
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: 30)
        lblScore?.text = "Score: 0!"
        
        self.addChild(lblScore!)
    }
    
    func spikeSpawnTimer(){
 
        let spikeTimer = SKAction.waitForDuration(spikeTimeSpawnNumber)
        let spawn = SKAction.runBlock{
            self.spawnSpike()
   
            self.updateScore()
            
        }
        
        let sequence = SKAction.sequence([spikeTimer, spawn])
        
        self.runAction(SKAction.repeatActionForever(sequence))
        
    }
    
    func hideLabel(){
        let wait = SKAction.waitForDuration(3.0)
        let hideLabel = SKAction.runBlock{
            lblMain?.alpha = 0.0
        }
        
        let sequnce = SKAction.sequence([wait, hideLabel])
        
        self.runAction(SKAction.repeatAction(sequnce, count: 1))
        
    }
    
    func didBeginContact(contact: SKPhysicsContact) {
        let firstBody : SKPhysicsBody = contact.bodyA
        let secondBody : SKPhysicsBody = contact.bodyB
        
        if ((firstBody.categoryBitMask == physicsCategory.player) && (secondBody.categoryBitMask == physicsCategory.spike) ||
            (firstBody.categoryBitMask == physicsCategory.spike) && (secondBody.categoryBitMask == physicsCategory.player)){
            
            spikeCollision(firstBody.node as! SKSpriteNode, spikeTemp: secondBody.node as! SKSpriteNode)
                
        }
        
        
    }
    
    func spikeCollision(playerTemp: SKSpriteNode, spikeTemp: SKSpriteNode){
        spikeTemp.removeFromParent()
        
        lblMain?.alpha = 1.0
        lblMain?.fontSize = 70
        lblMain?.text = "Game Over"
        
        isAlive = false
        
        updateScore()
        waitThenMoveToTitleScene()
        
    }
    
    func updateScore(){
        lblScore?.text = "Score: \(score)"
    }
    //
    
    func waitThenMoveToTitleScene(){
        let wait = SKAction.waitForDuration(1.0)
        let transition = SKAction.runBlock {
            self.view?.presentScene(TitleScene(), transition: SKTransition.crossFadeWithDuration(1.0))
        }
        
        let sequence = SKAction.sequence([wait, transition])
        
        self.runAction(SKAction.repeatAction(sequence, count: 1))
        
    }
    
    func addToScore(){
        let timeInterval = SKAction.waitForDuration(1.0)
        let addAndUpdateScore = SKAction.runBlock{
            score++
            self.updateScore()
        }
        
        let sequence = SKAction.sequence([timeInterval, addAndUpdateScore])
        
        self.runAction(SKAction.repeatActionForever(sequence))
        
        
    }
    
    
}
