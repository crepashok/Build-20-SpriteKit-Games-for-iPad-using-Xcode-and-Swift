//
//  TitleScene.swift
//  Avoid Spikes
//
//  Created by John Bura on 2015-12-11.
//  Copyright © 2015 Mammoth Interactive. All rights reserved.
//

import Foundation
import SpriteKit

class TitleScene : SKScene {
    
    var btnPlay : UIButton!
    var gameTitle : UILabel!
    
    override func didMoveToView(view: SKView) {
        self.backgroundColor = UIColor.orangeColor()
        
        setUpText()
    }
    
    func setUpText(){
        btnPlay = UIButton(frame: CGRect(x: 100, y: 100, width: 1100, height: 220))
        btnPlay.center = CGPoint(x: view!.frame.size.width / 2, y: 1100)
        btnPlay.titleLabel?.font = UIFont(name: "Futura", size: 150)
        
        btnPlay.setTitle("Play!", forState: UIControlState.Normal)
        btnPlay.setTitleColor(offBlackColor, forState: UIControlState.Normal)
        btnPlay.backgroundColor = offWhiteColor
        
        btnPlay.addTarget(self, action: Selector("playTheGame"), forControlEvents: UIControlEvents.TouchUpInside)
        self.view?.addSubview(btnPlay)
        
        gameTitle = UILabel(frame: CGRect(x: 0, y: 0, width: view!.frame.width, height: 300))
        gameTitle.textColor = offWhiteColor
        gameTitle.font = UIFont(name: "Futura", size: 130)
        gameTitle.textAlignment = NSTextAlignment.Center
        gameTitle.text = "AVOID SPIKES!"
        gameTitle.backgroundColor = offBlackColor
        
        self.view?.addSubview(gameTitle)
        
        
    }
    
    func playTheGame(){
        self.view?.presentScene(GameScene(), transition: SKTransition.crossFadeWithDuration(1.0))
        btnPlay.removeFromSuperview()
        gameTitle.removeFromSuperview()
        
        if let scene = GameScene(fileNamed: "GameScene"){
            let skView = self.view! as SKView
            
            skView.ignoresSiblingOrder = true
            
            scene.scaleMode = .AspectFill
            skView.presentScene(scene)
            
        }
    }
    
    
    
    
    
    
    
    
    
}
