//
//  GameScene.swift
//  Pick the Right Color
//
//  Created by John Bura on 2016-01-09.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved. 
//

import SpriteKit

var square0 = SKSpriteNode?()
var square1 = SKSpriteNode?()
var square2 = SKSpriteNode?()
var square3 = SKSpriteNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()
var lblTimer = SKLabelNode?()

var squareSize = CGSize(width: 200, height: 200)

var squarePositionOffset : CGFloat = 120

var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 0.2)

var color0 = UIColor.orangeColor()
var color1 = UIColor(red: (204 / 255), green: (255 / 255), blue: (102 / 255), alpha: 1.0)
var color2 = UIColor(red: (204 / 255), green: (102 / 255), blue: (255 / 255), alpha: 1.0)
var color3 = UIColor(red: (102 / 255), green: (204 / 255), blue: (255 / 255), alpha: 1.0)

var incorrectColor0 = UIColor.yellowColor()
var incorrectColor1 = UIColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1.0)
var incorrectColor2 = UIColor(red: (255 / 255), green: (29 / 255), blue: (20 / 255), alpha: 1.0)

var colorArrayString = ["Orange", "Green", "Purple", "Blue"]
var colorArrayChoice = 0

var colorChoice = 0

var correctSquare = 0

var touchLocation = CGPoint?()
var touchedNode = SKNode?()

var score = 0

var isAlive = true

var countDownTimerVar = 12



class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        self.backgroundColor = offBlackColor
        resetGameVariables()
        
        spawnLblMain()
        spawnLblScore()
        spawnLblTimer()
        
        countDownTimer()
        
        randomizeColors()
        
        
    }
    //
    func resetGameVariables(){
        score = 0
        isAlive = true
        countDownTimerVar = 12
        
        spawnSqaure0()
        spawnSqaure1()
        spawnSqaure2()
        spawnSqaure3()
        
        lblTimer?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 310)
    }
    
    func randomizeColors(){
        colorArrayChoice = Int(arc4random_uniform(4))
        colorChoice = Int(arc4random_uniform(4))
        correctSquare = Int(arc4random_uniform(4))

        printColorCorrectSquare()
        printColors()
    }
    //
    func printColors(){
        
        if colorChoice == 0{
            lblMain?.fontColor = color0
        }
        if colorChoice == 1{
            lblMain?.fontColor = color1
        }
        if colorChoice == 2{
            lblMain?.fontColor = color2
        }
        if colorChoice == 3{
            lblMain?.fontColor = color3
        }
        
        lblMain?.text = "\(colorArrayString[colorArrayChoice])"
    }
    
    func printColorCorrectSquare(){
        var tempColor = [color0, color1, color2, color3]
        
        if colorChoice == 0{
            square0?.color = tempColor[colorChoice]
            square1?.color = incorrectColor0
            square2?.color = incorrectColor1
            square3?.color = incorrectColor2
            
            square0?.name = "correct"
            square1?.name = "incorrect0"
            square2?.name = "incorrect1"
            square3?.name = "incorrect2"
            
        }
        if colorChoice == 1{
            square0?.color = incorrectColor1
            square1?.color = tempColor[colorChoice]
            square2?.color = incorrectColor2
            square3?.color = incorrectColor0
            
            square0?.name = "incorrect0"
            square1?.name = "correct"
            square2?.name = "incorrect1"
            square3?.name = "incorrect2"
        }
        if colorChoice == 2{
            square0?.color = incorrectColor1
            square1?.color = incorrectColor0
            square2?.color = tempColor[colorChoice]
            square3?.color = incorrectColor2
            
            square0?.name = "incorrect0"
            square1?.name = "incorrect1"
            square2?.name = "correct"
            square3?.name = "incorrect2"
        }
        if colorChoice == 3{
            square0?.color = incorrectColor1
            square1?.color = incorrectColor0
            square2?.color = incorrectColor2
            square3?.color = tempColor[colorChoice]
            
            square0?.name = "incorrect0"
            square1?.name = "incorrect1"
            square2?.name = "incorrect2"
            square3?.name = "correct"
        }
        
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
       
        
        for touch in touches {
            touchLocation = touch.locationInNode(self)
            
            
            touchedNode = nodeAtPoint(touchLocation!)
            
            if touchedNode?.name != "correct"{
                gameOverLogic()
                isAlive = false
            }
            
            if touchedNode?.name == "correct"{
                
                addToScore()
                randomizeColors()
            }
            
            
            
            
        }
    }
    //
    func addToScore(){
        score = score + 1
        updateScore()
    }
    
    func updateScore(){
        lblScore?.text = "Score: \(score)"
    }
    //
    func spawnSqaure0(){
        square0 = SKSpriteNode(color: offWhiteColor, size: squareSize)
        square0?.position = CGPoint(x: CGRectGetMidX(self.frame) - squarePositionOffset, y: CGRectGetMidY(self.frame) + squarePositionOffset)
        
        self.addChild(square0!)
        
    }
    func spawnSqaure1(){
        square1 = SKSpriteNode(color: offWhiteColor, size: squareSize)
        square1?.position = CGPoint(x: CGRectGetMidX(self.frame) + squarePositionOffset, y: CGRectGetMidY(self.frame) + squarePositionOffset)
        
        self.addChild(square1!)
        
        
    }
    func spawnSqaure2(){
        square2 = SKSpriteNode(color: offWhiteColor, size: squareSize)
        square2?.position = CGPoint(x: CGRectGetMidX(self.frame) - squarePositionOffset, y: CGRectGetMidY(self.frame) - squarePositionOffset)
        
        self.addChild(square2!)
        
    }
    func spawnSqaure3(){
        square3 = SKSpriteNode(color: offWhiteColor, size: squareSize)
        square3?.position = CGPoint(x: CGRectGetMidX(self.frame) + squarePositionOffset, y: CGRectGetMidY(self.frame) - squarePositionOffset)
        
        self.addChild(square3!)
        
    }
    //
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontColor = offWhiteColor
        lblMain?.fontSize = 100
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 270)
        
        lblMain?.text = "Start!"
        self.addChild(lblMain!)
        
    }
    //
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.fontColor = offWhiteColor
        lblScore?.fontSize = 50
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 360)
        
        lblScore?.text = "Score: \(score)"
        self.addChild(lblScore!)
    }
    
    func spawnLblTimer(){
        lblTimer = SKLabelNode(fontNamed: "Futura")
        lblTimer?.fontColor = offWhiteColor
        lblTimer?.fontSize = 80
        lblTimer?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 310)
        
        lblTimer?.text = "10"
        self.addChild(lblTimer!)
    }
    
    func countDownTimer(){
        let wait = SKAction.waitForDuration(1.0)
        let countDown = SKAction.runBlock{
            
            if isAlive == true{
                countDownTimerVar = countDownTimerVar - 1
            }
            
            if countDownTimerVar <= 10 && isAlive == true{
                lblTimer?.text = "\(countDownTimerVar)"
            }
            
            if countDownTimerVar <= 0{
                self.gameOverLogic()
            }
        }
        
        let sequence = SKAction.sequence([wait, countDown])
        self.runAction(SKAction.repeatAction(sequence, count: countDownTimerVar))
        
        
        
        
    }
    //
    
    func gameOverLogic(){
        lblMain?.fontColor = offWhiteColor
        lblMain?.text = "Game Over"
        
        lblTimer?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 250)
        lblTimer?.text = "Try Again"
        
        square0?.removeFromParent()
        square1?.removeFromParent()
        square2?.removeFromParent()
        square3?.removeFromParent()
        
        resetTheGame()
    }
    
    func resetTheGame(){
        let wait = SKAction.waitForDuration(4.0)
        let gameScene = GameScene(size: self.size)
        let transition = SKTransition.doorwayWithDuration(0.5)
        
        gameScene.scaleMode = SKSceneScaleMode.AspectFill
        
        let changeScene = SKAction.runBlock{
            self.scene?.view?.presentScene(gameScene, transition: transition)
        }
        
        let sequence = SKAction.sequence([wait, changeScene])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
        
    }
   //
    override func update(currentTime: CFTimeInterval) {
      
    }
}
