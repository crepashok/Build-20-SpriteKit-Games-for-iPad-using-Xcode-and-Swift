//
//  GameScene.swift
//  Whack a block iPad
//
//  Created by John Bura on 2016-01-11.
//  Copyright (c) 2016 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var blockGood = SKSpriteNode?()
var blockBad = SKSpriteNode?()

var lblMain = SKLabelNode?()
var lblScore = SKLabelNode?()
var lblTimer = SKLabelNode?()

var touchedNode = SKNode?()

var touchLocation = CGPoint?()

var blockSize = CGSize(width: 50, height: 50)

var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)
var greenColorCustom = UIColor.greenColor()
var redColorCustom = UIColor.redColor()

var score = 0

var isCollecting = true
var isComplete = false

var timerCountDown = 32

var gameLabelAlpha : CGFloat = 0.5

var goodBlockSpawnTime = 1.0
var badBlockSpawnTime = 2.0

//
class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        self.backgroundColor = offWhiteColor
        resetTheVariablesOnStart()
        
        spawnLblMain()
        spawnLblScore()
        spawnLblTimer()
        
        countDownTimerLogic()
        blockBadTimer()
        blockGoodTimer()
        
        
    }
    
    func resetTheVariablesOnStart(){
        score = 0
        
        isCollecting = true
        isComplete = false
        
        timerCountDown = 32
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
       
        
        for touch in touches {
            touchLocation = touch.locationInNode(self)
            touchedNode = nodeAtPoint(touchLocation!)
            
            touchedGreenBlockLogic()
            touchedRedBlockLogic()
        }
    }
    
    func touchedGreenBlockLogic(){
        if touchedNode?.name == "blockGoodName"{
            score = score + 1
            touchedNode?.removeFromParent()
            updateScore()
        }
    }
    
    func touchedRedBlockLogic(){
        if touchedNode?.name == "blockBadName"{
            gameOverLogic()
        }
    }
    
    func updateScore(){
        lblScore?.text = "Score: \(score)"
    }
    
    func spawnBlockGood(){
        let randomX = Int(arc4random_uniform(500) + 300)
        let randomY = Int(arc4random_uniform(500) + 100)
        
        
        blockGood = SKSpriteNode(color: greenColorCustom, size: blockSize)
        blockGood?.position = CGPoint(x: randomX, y: randomY)
        blockGood?.name = "blockGoodName"
        
        self.addChild(blockGood!)
        
    }
    
    func spawnBlockBad(){
        let randomX = Int(arc4random_uniform(500) + 300)
        let randomY = Int(arc4random_uniform(500) + 100)
        
        
        blockBad = SKSpriteNode(color: redColorCustom, size: blockSize)
        blockBad?.position = CGPoint(x: randomX, y: randomY)
        blockBad?.name = "blockBadName"
        
        self.addChild(blockBad!)
        
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) + 250)
        lblMain?.fontSize = 50
        lblMain?.fontColor = offBlackColor
        lblMain?.text = "Collect Green Blocks"
        
        self.addChild(lblMain!)
        
    }
    
    func spawnLblScore(){
        lblScore = SKLabelNode(fontNamed: "Futura")
        lblScore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 350)
        lblScore?.fontSize = 40
        lblScore?.fontColor = offBlackColor
        lblScore?.text = "Score: \(score)"
        
        self.addChild(lblScore!)
        
    }
    
    func spawnLblTimer(){
        lblTimer = SKLabelNode(fontNamed: "Futura")
        lblTimer?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMidY(self.frame) - 250)
        lblTimer?.fontSize = 180
        lblTimer?.fontColor = offBlackColor
        lblTimer?.text = "\(timerCountDown - 2)"
        
        self.addChild(lblTimer!)
        
    }
    
    func countDownTimerLogic(){
        let wait = SKAction.waitForDuration(1.0)
        let countDown = SKAction.runBlock{
            timerCountDown = timerCountDown - 1
            
            if timerCountDown <= 30 && isCollecting == true{
                lblMain?.alpha = gameLabelAlpha
                lblMain?.zPosition = -1
                
                lblScore?.alpha = gameLabelAlpha
                lblScore?.zPosition = -1
                
                lblTimer?.alpha = gameLabelAlpha
                lblTimer?.zPosition = -1
                
                lblTimer?.text = "\(timerCountDown)"
            }
        }
        
        let sequnce = SKAction.sequence([wait, countDown])
        self.runAction(SKAction.repeatAction(sequnce, count: timerCountDown))
    }
    
    func blockGoodTimer(){
        let wait = SKAction.waitForDuration(goodBlockSpawnTime)
        let spawn = SKAction.runBlock{
            
            if isCollecting == true{
                self.spawnBlockGood()
            }
        }
        
        let sequence = SKAction.sequence([wait, spawn])
        self.runAction(SKAction.repeatAction(sequence, count: 32))
    }
    
    func blockBadTimer(){
        let wait = SKAction.waitForDuration(badBlockSpawnTime)
        let spawn = SKAction.runBlock{
            
            if isCollecting == true{
                self.spawnBlockBad()
            }
        }
        
        let sequence = SKAction.sequence([wait, spawn])
        self.runAction(SKAction.repeatAction(sequence, count: 17))
    }
    
    func gameOverLogic(){
        self.enumerateChildNodesWithName("blockGoodName", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.removeFromParent()
            }
        })
        
        self.enumerateChildNodesWithName("blockBadName", usingBlock: { node, stop in
            if let sprite = node as? SKSpriteNode{
                sprite.removeFromParent()
            }
        })
        
        isCollecting = false
        isComplete = true
        
        lblMain?.alpha = 1.0
        lblMain?.text = "Game Over"
        
        lblScore?.alpha = 1.0
 
        lblTimer?.alpha = 1.0
        lblTimer?.text = ""
        
        resetGame()
    }
    
    func resetGame(){
        let wait = SKAction.waitForDuration(3.0)
        let theGameScene = GameScene(size: self.size)
        theGameScene.scaleMode = SKSceneScaleMode.AspectFill
        let theTransition = SKTransition.fadeWithDuration(1.0)
        
        let changeScene = SKAction.runBlock{
            self.scene?.view?.presentScene(theGameScene, transition: theTransition)
        }
        
        let sequence = SKAction.sequence([wait, changeScene])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
        
    }
    //
    override func update(currentTime: CFTimeInterval) {
        
    }
}
