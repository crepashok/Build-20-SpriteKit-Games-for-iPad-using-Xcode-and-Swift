//
//  GameScene.swift
//  Click as fast as you can
//
//  Created by John Bura on 2015-12-16.
//  Copyright (c) 2015 Mammoth Interactive. All rights reserved.
//

import SpriteKit

var lblMain = SKLabelNode?()
var lblSore = SKLabelNode?()

var square = SKSpriteNode?()

var backgroundColorCustomOrange = UIColor.orangeColor()
var offBlackColor = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 1.0)
var offWhiteColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)

var touchLocation = CGPoint?()
var touchedNode = SKNode?()

var introMessage = ["Ready!","Set!","GO!!!"]

var timerCounter = -1
var canClick = false
var score = 0


class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        
        self.backgroundColor = backgroundColorCustomOrange
  
        spawnLblMain()
        spawnLblScore()
        startGameTimer()
       resetVariablesOnStart()
       
    }
    
    func resetVariablesOnStart(){
        timerCounter = -1
        canClick = false
        score = 0
    }
    //
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        for touch in touches {
            touchLocation = touch.locationInNode(self)
            touchedNode = nodeAtPoint(touchLocation!)
            
            if canClick == true{
                touchedNodeLogic()
            }
        }
    }
   
    override func update(currentTime: CFTimeInterval) {
     
    }
    
    func spawnLblMain(){
        lblMain = SKLabelNode(fontNamed: "Futura")
        lblMain?.fontColor = offWhiteColor
        lblMain?.fontSize = 180
        lblMain?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMinY(self.frame) + 170)
        lblMain?.text = "\(introMessage[0])"
        
        self.addChild(lblMain!)
    }
    
    func spawnLblScore(){
        lblSore = SKLabelNode(fontNamed: "Futura")
        lblSore?.fontColor = offBlackColor
        lblSore?.fontSize = 90
        lblSore?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMinY(self.frame) + 30)
        
        
        lblSore?.text = "Score: 0"
        
        self.addChild(lblSore!)
    }
    
    func startGameTimer(){
        let wait = SKAction.waitForDuration(1.0)
        let countDownTimer = SKAction.runBlock{
            timerCounter++

            if timerCounter < 0{
                lblMain?.text = "Ready!"
            }
           
            if timerCounter == 0{
                lblMain?.text = "\(introMessage[timerCounter])"
            }
            if timerCounter == 1{
                lblMain?.text = "\(introMessage[timerCounter])"
            }
            if timerCounter == 2{
                lblMain?.text = "\(introMessage[timerCounter])"
                 self.spawnSqaure()
                canClick = true
            }
            
            if timerCounter == 10{
                self.gameOverLogic()
            }
        }
        
        let seqeunce = SKAction.sequence([wait, countDownTimer])
        self.runAction(SKAction.repeatActionForever(seqeunce))
        
        
    }
    
    func spawnSqaure(){
        square = SKSpriteNode(color: offWhiteColor, size: CGSize(width: 300, height: 300))
        
        square?.position = CGPoint(x: CGRectGetMidX(self.frame), y: CGRectGetMaxY(self.frame) - 220)
        square?.name = "touchedSquare"
        
        self.addChild(square!)
    }
    //

    func touchedNodeLogic(){
        
        if let nodeName = touchedNode?.name{
            
            if nodeName == "touchedSquare"{
                score = score + 1
                updateScore()
            }
            
            
        }
    }
    
    func updateScore(){
        lblSore?.text = "Score: \(score)"
    }
//
    func gameOverLogic(){
        square?.removeFromParent()
        canClick = false
        
        lblMain?.fontSize = 100
        lblMain?.text = "Game Over"

        let gameScene = GameScene(size: self.size)
        let transition = SKTransition.doorwayWithDuration(0.9)
        
        gameScene.scaleMode = SKSceneScaleMode.AspectFill
        
        let wait = SKAction.waitForDuration(3.0)
        let runTransition = SKAction.runBlock{
            
            self.scene!.view?.presentScene(gameScene, transition: transition)
        }

        let sequence = SKAction.sequence([wait, runTransition])
        self.runAction(SKAction.repeatAction(sequence, count: 1))
        
    }
    
    
}
